﻿//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Data;
//using System.Data.SqlClient;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using ValidateLicence;


//namespace DB_AUTOBACKUP_UTILITY
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string Licence = ConfigurationManager.AppSettings["LICENCE"];
//            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
//            var isPCLicenceOK = true;
//            var custId = "eviska";
//            //isPCLicenceOK = VerifyDetails.ComparePCLicense(toDate, custId);
//            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
//            SqlConnection connection = new SqlConnection(connectionString);
//            if (DateTime.Today > toDate)
//            {
//                Console.WriteLine("Licence expired");
//                Console.ReadKey();
//                return;
//            }
//            //if (isPCLicenceOK == false)
//            //{
//            //    Console.WriteLine("Not Valid User");
//            //    Console.ReadKey();
//            //    return;
//            //}
//            //DateTime modification = File.GetLastWriteTime(@"D:\pratiksha\DB_AUTOBACKUP_UTILITY\App.config");
//            DateTime date = DateTime.Now;
//            StringBuilder logs = new StringBuilder();
//            StringBuilder errorLogs = new StringBuilder();
//            StringBuilder fileContents = new StringBuilder();
//            //Console.WriteLine("Inside method");
//            string fileName_DateFormat = ConfigurationManager.AppSettings["FILENAME_DATE_FORMAT"];
//            string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
//            string FolderName = localFolderPath;
//            string dbname = ConfigurationManager.AppSettings["DBNAME"];
//            string FilePath = ConfigurationManager.AppSettings["DBFILESPATH"];
//            string name = dbname + "-Full Database Backup";
//            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\ErrorLogs.txt";
//            try
//            {
//                foreach (string file in Directory.EnumerateFiles(localFolderPath, "*.bak"))
//                {
//                    string filename = Path.GetFileName(file);
//                    DateTime creationTime = File.GetCreationTime(file);
//                    string creationDay = creationTime.DayOfWeek.ToString();
//                    if (creationDay == DateTime.Now.DayOfWeek.ToString())
//                    {
//                        File.Delete(Path.Combine(FolderName, filename));
//                    }
//                }
//            }
//            catch(Exception ex)
//            {
//                var fs1 = System.IO.File.Open(logFolder, FileMode.Append, FileAccess.Write, FileShare.Write);
//                using (StreamWriter writer = new StreamWriter(fs1))
//                {
//                    logs.AppendLine(ex.InnerException.ToString());
//                    writer.WriteLine(logs);
//                    writer.Close();
//                    Console.WriteLine(ex.Message);
//                    Console.ReadKey();
//                }
//            }

//            //Console.WriteLine("Inside method1");
//            localFolderPath = localFolderPath + dbname + date.ToString(fileName_DateFormat) +".bak";
//           // localFolderPath = localFolderPath + dbname + ".bak";
//            try
//            {
//                string[] filePaths = Directory.GetFiles(FilePath);
//                connection.Open();
//                SqlCommand cmd = new SqlCommand("SP_DBBACKUP", connection);
//                cmd.CommandTimeout = 2000;
//                cmd.CommandType = CommandType.StoredProcedure;
//                cmd.Parameters.Add(new SqlParameter("@path", SqlDbType.NVarChar)).Value = localFolderPath;
//                cmd.Parameters.Add(new SqlParameter("@name", SqlDbType.NVarChar)).Value = name;
//                cmd.ExecuteNonQuery();
//                connection.Close();
//                var fs = System.IO.File.Open(logFolder, FileMode.Append, FileAccess.Write, FileShare.Write);
//                using (StreamWriter writer = new StreamWriter(fs))
//                {
//                    logs.AppendLine("Backup Created Successfully..!");
//                    writer.WriteLine(logs);
//                    writer.Close();

//                }
//                Console.WriteLine("Backup Created Successfully..!");
//            }
//            catch(Exception ex)
//            {
//                var fs1 = System.IO.File.Open(logFolder, FileMode.Append, FileAccess.Write, FileShare.Write);
//                using (StreamWriter writer = new StreamWriter(fs1))
//                {
//                    logs.AppendLine(ex.InnerException.ToString());
//                    writer.WriteLine(logs);
//                    writer.Close();
//                    Console.WriteLine(ex.Message);
//                    Console.ReadKey();
//                }
//            }
//        }
//    }
//}


using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using ValidateLicence;

namespace DB_AUTOBACKUP_UTILITY
{
    class Program
    {
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            var custId = "eviska";
            var isPCLicenceOK = true;

            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }

            string fileName_DateFormat = ConfigurationManager.AppSettings["FILENAME_DATE_FORMAT"];
            string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            string dbName = ConfigurationManager.AppSettings["DBNAME"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\ErrorLogs.txt";

            DateTime date = DateTime.Now;
            StringBuilder logs = new StringBuilder();

            // Unique backup file name with date format
            string backupFileName = $"{dbName}_{date.ToString(fileName_DateFormat)}.bak";
            string backupFilePath = Path.Combine(localFolderPath, backupFileName);

            // Generate backup
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string backupQuery = $@"
                        BACKUP DATABASE [{dbName}]
                        TO DISK = @BackupPath
                        WITH FORMAT,
                             INIT,
                             NAME = @BackupName,
                             SKIP,
                             NOREWIND,
                             NOUNLOAD,
                             STATS = 10;";

                    using (SqlCommand cmd = new SqlCommand(backupQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@BackupPath", backupFilePath);
                        cmd.Parameters.AddWithValue("@BackupName", $"{dbName} - Full Database Backup");
                        cmd.CommandTimeout = 2000;

                        cmd.ExecuteNonQuery();
                    }
                }

                LogMessage(logFolder, "Backup Created Successfully..!", logs);
                Console.WriteLine("Backup Created Successfully..!");
            }
            catch (Exception ex)
            {
                LogError(logFolder, ex, logs);
            }
        }

        private static void LogError(string logFolder, Exception ex, StringBuilder logs)
        {
            try
            {
                using (var fs = File.Open(logFolder, FileMode.Append, FileAccess.Write, FileShare.Write))
                using (var writer = new StreamWriter(fs))
                {
                    logs.AppendLine(ex.Message);
                    if (ex.InnerException != null)
                        logs.AppendLine(ex.InnerException.ToString());

                    writer.WriteLine(logs);
                }
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            catch
            {
                Console.WriteLine("Failed to write error log.");
            }
        }

        private static void LogMessage(string logFolder, string message, StringBuilder logs)
        {
            try
            {
                using (var fs = File.Open(logFolder, FileMode.Append, FileAccess.Write, FileShare.Write))
                using (var writer = new StreamWriter(fs))
                {
                    logs.AppendLine(message);
                    writer.WriteLine(logs);
                }
            }
            catch
            {
                Console.WriteLine("Failed to write log.");
            }
        }
    }
}


