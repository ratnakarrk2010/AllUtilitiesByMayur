﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using ValidateLicence;

namespace Jeena_DataTransferUtility
{
    class Program
    {
        static StringBuilder sb = new StringBuilder("");
        static void Main(string[] args)
        {
            string _swipedata_connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            string _Nitgen_connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING1"];
            string _etimetracklite_connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING2"];
            string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
            string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataSet ds_Nitgen = new DataSet();
            DataSet ds_etimetracklite = new DataSet();

            DataTable dt_FIRSTIN_LASTOUT = new DataTable();
            DataSet ds_FIRSTIN_LASTOUT = new DataSet();
            dt_FIRSTIN_LASTOUT.Columns.Add("EmpCode");
            dt_FIRSTIN_LASTOUT.Columns.Add("EntryDate");
            dt_FIRSTIN_LASTOUT.Columns.Add("EntryTime");
            dt_FIRSTIN_LASTOUT.Columns.Add("UpdateUID");
            dt_FIRSTIN_LASTOUT.Columns.Add("Location");


            DataTable dt_FIRSTIN_LASTOUT1 = new DataTable();
            DataSet ds_FIRSTIN_LASTOUT1 = new DataSet();
            dt_FIRSTIN_LASTOUT1.Columns.Add("EmpCode");
            dt_FIRSTIN_LASTOUT1.Columns.Add("EntryDate");
            dt_FIRSTIN_LASTOUT1.Columns.Add("EntryTime");
            dt_FIRSTIN_LASTOUT1.Columns.Add("UpdateUID");
            dt_FIRSTIN_LASTOUT1.Columns.Add("Location");

            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
            {
                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                myFile.Close();
            }
            try
            {
                using (SqlConnection connection = new SqlConnection(_swipedata_connectionString))
                {
                    connection.Open();

                    sb.AppendLine("-----------------------------------" + DateTime.Now + "-----------------------------------");
                    sb.AppendLine("Connection established successfully for SWIPEDATA. " + DateTime.Now);

                    string queryString = "select * from table_NGAC_AUTHLOG";
                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.Fill(ds_Nitgen);

                    string queryString1 = "select * from table_etimetracklite";
                    SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                    adapter1.Fill(ds_etimetracklite);

                    if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);
                    if (ds_etimetracklite.Tables[0].Rows[0][1].ToString() != tblDeviceLogs)
                    {
                        string query1 = "update table_etimetracklite set DeviceLogId='" + 0 + "', Table_Name='" + tblDeviceLogs + "'";
                        SqlCommand cmd2 = new SqlCommand(query1, connection);
                        cmd2.ExecuteNonQuery();

                        ds_etimetracklite.Clear();
                        string queryString2 = "select * from table_etimetracklite";
                        SqlDataAdapter adapter2 = new SqlDataAdapter(queryString2, connection);
                        adapter1.Fill(ds_etimetracklite);

                        sb.AppendLine("table_etimetracklite updated change TableName To " + tblDeviceLogs + ". " + DateTime.Now);
                        try
                        {
                            string IndexName = "IX_" + tblDeviceLogs + "_DeviceLogId";
                            using (SqlConnection connection1 = new SqlConnection(_etimetracklite_connectionString))
                            {
                                connection1.Open();
                                using (SqlCommand cmd = new SqlCommand("CREATE INDEX " + IndexName + " ON " + tblDeviceLogs + " (DeviceLogId) INCLUDE ([DeviceId], [UserId], [LogDate])", connection1))
                                {
                                    cmd.ExecuteNonQuery();
                                }
                                connection1.Close();
                            }
                        }
                        catch(Exception ex)
                        {
                            sb.AppendLine("Inside the catch of Indexing. " + DateTime.Now);
                            sb.AppendLine(ex + "" + DateTime.Now);
                            sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                            File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", sb.ToString());
                            Console.WriteLine(ex.Message);
                            Console.ReadKey();
                        }
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine(ex + "" + DateTime.Now);
                sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", sb.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            try 
            {
                using (SqlConnection connection = new SqlConnection(_Nitgen_connectionString))
                {
                    connection.Open();
                    sb.AppendLine("Connection established successfully for NitgenAccessManager. " + DateTime.Now);

                    //string queryString = "select top(1000) userId as EmpCode,CONVERT(nvarchar(10), transactionTime, 120) as EntryDate, transactionTime as Entrytime,TerminalID as updateUID, NGAC_TERMINAL.Name as Location,IndexKey from NGAC_AUTHLOG join NGAC_TERMINAL on(NGAC_AUTHLOG.TerminalID= NGAC_TERMINAL.ID)where IndexKey> '" + ds_Nitgen.Tables[0].Rows[0][0] + "' order by IndexKey";

                    string queryString = @"
    SELECT 
        userId AS EmpCode,
        CONVERT(NVARCHAR(10), transactionTime, 120) AS EntryDate,
        transactionTime AS Entrytime,
        TerminalID AS updateUID,
        NGAC_TERMINAL.Name AS Location,
        IndexKey 
    FROM NGAC_AUTHLOG 
    JOIN NGAC_TERMINAL ON NGAC_AUTHLOG.TerminalID = NGAC_TERMINAL.ID
    WHERE transactionTime BETWEEN '2024-05-23' AND '2024-06-01'
    ORDER BY IndexKey;";

                    // string queryString = "select userId as EmpCode,CONVERT(nvarchar(10), transactionTime, 120) as EntryDate, transactionTime as Entrytime,TerminalID as updateUID, NGAC_TERMINAL.Name as Location,IndexKey from NGAC_AUTHLOG join NGAC_TERMINAL on(NGAC_AUTHLOG.TerminalID= NGAC_TERMINAL.ID)where IndexKey>7459298 order by IndexKey ";
                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.Fill(ds);

                    sb.AppendLine("Data fetched from NitgenAccessManager. " + DateTime.Now);

                    connection.Close();
                }
                using (SqlConnection connection = new SqlConnection(_etimetracklite_connectionString))
                {
                    connection.Open();

                    sb.AppendLine("Connection established successfully for etimetracklite. " + DateTime.Now);

                     //string queryString = "select top(1000) UserId as EmpCode,CONVERT(nvarchar(10), LogDate, 120) as EntryDate,LogDate as Entrytime,Devices.DeviceId as updateUID,Devices.DeviceSName as Location,DeviceLogId from " + tblDeviceLogs + " join devices on(Devices.DeviceId= " + tblDeviceLogs + ".DeviceId) where DeviceLogId>'" + ds_etimetracklite.Tables[0].Rows[0][0] + "' order by DeviceLogId";
                    string queryString = @"
            SELECT 
                UserId AS EmpCode,
                CONVERT(NVARCHAR(10), LogDate, 120) AS EntryDate,
                LogDate AS Entrytime,
                Devices.DeviceId AS updateUID,
                Devices.DeviceSName AS Location,
                DeviceLogId 
            FROM DeviceLogs_5_2024 
            JOIN Devices ON DeviceLogs_5_2024.DeviceId = Devices.DeviceId 
            WHERE LogDate BETWEEN '2024-05-23' AND '2024-06-01'
              
            ORDER BY DeviceLogId;";

                    //  string queryString = "select top (10) UserId as EmpCode,CONVERT(nvarchar(10), LogDate, 120) as EntryDate,LogDate as Entrytime,Devices.DeviceId as updateUID,Devices.DeviceFName,DeviceLogId from DeviceLogs_9_2023 join devices on(Devices.DeviceId= DeviceLogs_9_2023 .DeviceId) where DeviceLogId>400 order by DeviceLogId ";
                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.Fill(ds1);

                    sb.AppendLine("Data fetched from etimetracklite. " + DateTime.Now);
                    connection.Close();
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    using (SqlConnection connection1 = new SqlConnection(_swipedata_connectionString))
                    {
                        SqlBulkCopy objbulk = new SqlBulkCopy(connection1);
                        objbulk.DestinationTableName = "AttenInfo";
                        objbulk.ColumnMappings.Add("EmpCode", "EmpCode");
                        objbulk.ColumnMappings.Add("EntryDate", "EntryDate");
                        objbulk.ColumnMappings.Add("EntryTime", "EntryTime");
                        objbulk.ColumnMappings.Add("UpdateUID", "UpdateUID");
                        objbulk.ColumnMappings.Add("Location", "Location");

                        connection1.Open();

                        /*DataTable dt = ds.Tables[0];
                         var employeeDataGroup = dt.AsEnumerable().GroupBy(x => x.ItemArray[0]).ToList();

                        foreach (var empGroup in employeeDataGroup)
                        {
                            var firstIN = empGroup.FirstOrDefault();
                            var lastOUT = empGroup.LastOrDefault();

                            if (firstIN.ItemArray[2].ToString() == lastOUT.ItemArray[2].ToString())
                            {
                                DataRow dr_IN = dt_FIRSTIN_LASTOUT.NewRow();
                                dr_IN["EmpCode"] = firstIN.ItemArray[0];
                                dr_IN["EntryDate"] = firstIN.ItemArray[1];
                                dr_IN["EntryTime"] = firstIN.ItemArray[2];
                                dr_IN["UpdateUID"] = firstIN.ItemArray[3];
                                dr_IN["Location"] = firstIN.ItemArray[4];
                                dt_FIRSTIN_LASTOUT.Rows.Add(dr_IN);
                            }
                            else
                            {
                                DataRow dr_IN = dt_FIRSTIN_LASTOUT.NewRow();
                                dr_IN["EmpCode"] = firstIN.ItemArray[0];
                                dr_IN["EntryDate"] = firstIN.ItemArray[1];
                                dr_IN["EntryTime"] = firstIN.ItemArray[2];
                                dr_IN["UpdateUID"] = firstIN.ItemArray[3];
                                dr_IN["Location"] = firstIN.ItemArray[4];
                                dt_FIRSTIN_LASTOUT.Rows.Add(dr_IN);

                                dr_IN = dt_FIRSTIN_LASTOUT.NewRow();
                                dr_IN["EmpCode"] = lastOUT.ItemArray[0];
                                dr_IN["EntryDate"] = lastOUT.ItemArray[1];
                                dr_IN["EntryTime"] = lastOUT.ItemArray[2];
                                dr_IN["UpdateUID"] = lastOUT.ItemArray[3];
                                dr_IN["Location"] = lastOUT.ItemArray[4];
                                dt_FIRSTIN_LASTOUT.Rows.Add(dr_IN);
                            }
                        }
                        ds_FIRSTIN_LASTOUT.Tables.Add(dt_FIRSTIN_LASTOUT);
                        objbulk.WriteToServer(ds_FIRSTIN_LASTOUT.Tables[0]); */

                        DataTable dt = ds.Tables[0];
                        objbulk.WriteToServer(ds.Tables[0]);
                        sb.AppendLine("Data transfer successfully from NitgenAccessManager. " + DateTime.Now);

                        DataRow lastRow = dt.Rows[dt.Rows.Count - 1];
                        string query = "update table_NGAC_AUTHLOG set IndexKey='" + lastRow.ItemArray[5] + "'";
                        SqlCommand cmd1 = new SqlCommand(query, connection1);
                        cmd1.ExecuteNonQuery();

                        sb.AppendLine("table_NGAC_AUTHLOG updated successfully. " + DateTime.Now);

                        connection1.Close();
                    }
                }

                if (ds1.Tables[0].Rows.Count > 0)
                {
                    using (SqlConnection connection1 = new SqlConnection(_swipedata_connectionString))
                    {
                        SqlBulkCopy objbulk = new SqlBulkCopy(connection1);
                        objbulk.DestinationTableName = "AttenInfo";
                        objbulk.ColumnMappings.Add("EmpCode", "EmpCode");
                        objbulk.ColumnMappings.Add("EntryDate", "EntryDate");
                        objbulk.ColumnMappings.Add("EntryTime", "EntryTime");
                        objbulk.ColumnMappings.Add("UpdateUID", "UpdateUID");
                        objbulk.ColumnMappings.Add("Location", "Location");

                        connection1.Open();

                        /*DataTable dt = ds1.Tables[0];
                        var employeeDataGroup = dt.AsEnumerable().GroupBy(x => x.ItemArray[0]).ToList();

                        foreach (var empGroup in employeeDataGroup)
                        {
                            var firstIN = empGroup.FirstOrDefault();
                            var lastOUT = empGroup.LastOrDefault();

                            if (firstIN.ItemArray[2].ToString() == lastOUT.ItemArray[2].ToString())
                            {
                                DataRow dr_IN = dt_FIRSTIN_LASTOUT1.NewRow();
                                dr_IN["EmpCode"] = firstIN.ItemArray[0];
                                dr_IN["EntryDate"] = firstIN.ItemArray[1];
                                dr_IN["EntryTime"] = firstIN.ItemArray[2];
                                dr_IN["UpdateUID"] = firstIN.ItemArray[3];
                                dr_IN["Location"] = firstIN.ItemArray[4];
                                dt_FIRSTIN_LASTOUT1.Rows.Add(dr_IN);
                            }
                            else
                            {
                                DataRow dr_IN = dt_FIRSTIN_LASTOUT1.NewRow();
                                dr_IN["EmpCode"] = firstIN.ItemArray[0];
                                dr_IN["EntryDate"] = firstIN.ItemArray[1];
                                dr_IN["EntryTime"] = firstIN.ItemArray[2];
                                dr_IN["UpdateUID"] = firstIN.ItemArray[3];
                                dr_IN["Location"] = firstIN.ItemArray[4];
                                dt_FIRSTIN_LASTOUT1.Rows.Add(dr_IN);

                                dr_IN = dt_FIRSTIN_LASTOUT1.NewRow();
                                dr_IN["EmpCode"] = lastOUT.ItemArray[0];
                                dr_IN["EntryDate"] = lastOUT.ItemArray[1];
                                dr_IN["EntryTime"] = lastOUT.ItemArray[2];
                                dr_IN["UpdateUID"] = lastOUT.ItemArray[3];
                                dr_IN["Location"] = lastOUT.ItemArray[4];
                                dt_FIRSTIN_LASTOUT1.Rows.Add(dr_IN);
                            }
                        }

                        ds_FIRSTIN_LASTOUT1.Tables.Add(dt_FIRSTIN_LASTOUT1);
                        objbulk.WriteToServer(ds_FIRSTIN_LASTOUT1.Tables[0]); */

                        objbulk.WriteToServer(ds1.Tables[0]);

                        sb.AppendLine("Data transfer successfully from etimetracklite. " + DateTime.Now);
                        
                        DataTable dt1 = ds1.Tables[0];
                        DataRow lastRow1 = dt1.Rows[dt1.Rows.Count - 1];

                        string query1 = "update table_etimetracklite set DeviceLogId='" + lastRow1.ItemArray[5] + "'";
                        SqlCommand cmd2 = new SqlCommand(query1, connection1);
                        cmd2.ExecuteNonQuery();

                        sb.AppendLine("table_etimetracklite updated successfully. " + DateTime.Now);
                        
                        connection1.Close();
                    }
                }
                sb.AppendLine("Data transfer successfully." + "" + DateTime.Now);
                sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", sb.ToString());
            }
            catch(Exception ex)
            {
                sb.AppendLine(ex + "" + DateTime.Now);
                sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", sb.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
    }
}
