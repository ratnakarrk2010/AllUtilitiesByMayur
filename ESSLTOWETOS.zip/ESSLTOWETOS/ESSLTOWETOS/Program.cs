﻿//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Data;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ESSLTOWETOS
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
//            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
//            string deviceLogTable = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
//            StringBuilder logs = new StringBuilder();
//            DateTime logDateToFetch = DateTime.Now.AddDays(-logDateInDays);

//            try
//            {
//                using (SqlConnection connection = new SqlConnection(connectionString))
//                {
//                    connection.Open();
//                    Console.WriteLine("Connection established successfully..!");
//                    using (SqlCommand cmd = new SqlCommand("SP_ESSLTOWETOS", connection))
//                    {
//                        string today = logDateToFetch.ToString("yyyy-MM-dd");
//                        DateTime today1 = DateTime.Now;
//                        deviceLogTable += today1.Month + "_" + today1.Year;

//                        cmd.CommandType = CommandType.StoredProcedure;
//                        cmd.Parameters.Add("@DeviceLogs_Table", SqlDbType.NVarChar).Value = deviceLogTable;
//                        SqlDataAdapter adapter = new SqlDataAdapter();
//                        adapter.SelectCommand = cmd;
//                        cmd.ExecuteNonQuery();
//                        Console.WriteLine("Procedure call..!");
//                        cmd.CommandTimeout = 50000;
//                        Console.WriteLine("Data inserted successfully");
//                    }
//                    connection.Close();
//                }
//            }
//            catch(Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//                Console.ReadKey();
//            }
//        }
//    }
//}


using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;
using Npgsql;

namespace ESSLTOWETOS
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourceConnectionString =
                ConfigurationManager.ConnectionStrings["SOURCE_CONNECTION_STRING"].ConnectionString;

            string destinationConnectionString =
                ConfigurationManager.ConnectionStrings["DESTINATION_CONNECTION_STRING"].ConnectionString;

            string deviceLogPrefix =
                ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];

            int logDateInDays =
                Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);

            string logPath =
                ConfigurationManager.AppSettings["LOG_FILE_PATH"];

            DateTime tableDate = DateTime.Now.AddDays(-logDateInDays);

            string deviceLogTable = GetDeviceLogTable(
                deviceLogPrefix, tableDate);

            DataTable punches = new DataTable();

            try
            {
                WriteLog(logPath, "Process started.");
                WriteLog(logPath, "Source table: " + deviceLogTable);

                using (SqlConnection sourceConnection =
                    new SqlConnection(sourceConnectionString))
                {
                    sourceConnection.Open();
                    WriteLog(logPath, "Source SQL Server connected.");

                    string selectQuery = @"
                        SELECT
                            LTRIM(RTRIM(E.EmployeeCode)) AS EmployeeCode,
                            CAST(D.Logdate AS date) AS CmnDate,
                            D.Logdate AS CmnTime,
                            D.DeviceId AS DeviceNo,
                            E.CompanyId AS CompanyId,
                            1 AS BranchId,
                            D.UserId AS SourceUserId,
                            D.Logdate AS SourceLogDate
                        FROM [etimetracklite1].[dbo].[Employees] E
                        INNER JOIN " + deviceLogTable + @" D
                            ON D.UserId = E.EmployeeCode
                        WHERE D.UpdateFlag <> 1
                          AND D.UserId IS NOT NULL;";

                    using (SqlCommand cmd =
                        new SqlCommand(selectQuery, sourceConnection))
                    {
                        cmd.CommandTimeout = 50000;

                        using (SqlDataAdapter adapter =
                            new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(punches);
                        }
                    }

                    WriteLog(logPath,
                        "Source records fetched: " + punches.Rows.Count);

                    if (punches.Rows.Count == 0)
                    {
                        WriteLog(logPath, "No pending records found.");
                        return;
                    }

                    // Insert into PostgreSQL first.
                    using (NpgsqlConnection destinationConnection =
                        new NpgsqlConnection(destinationConnectionString))
                    {
                        destinationConnection.Open();

                        WriteLog(logPath,
                            "Destination PostgreSQL connected.");

                        using (NpgsqlTransaction transaction =
                            destinationConnection.BeginTransaction())
                        {
                            try
                            {
                                string insertQuery = @"
                                    INSERT INTO public.""CommanData""
                                    (
                                        ""EmployeeCode"",
                                        ""CmnDate"",
                                        ""CmnTime"",
                                        ""DeviceNo"",
                                        ""Status"",
                                        ""CompanyId"",
                                        ""BranchId"",
                                        ""DeviceName"",
                                        ""AttendanceYearId""
                                    )
                                    VALUES
                                    (
                                        @EmployeeCode,
                                        @CmnDate,
                                        @CmnTime,
                                        @DeviceNo,
                                        @Status,
                                        @CompanyId,
                                        @BranchId,
                                        @DeviceName,
                                        @AttendanceYearId
                                    );";

                                using (NpgsqlCommand insertCommand =
                                    new NpgsqlCommand(
                                        insertQuery,
                                        destinationConnection,
                                        transaction))
                                {
                                    insertCommand.Parameters.Add(
                                        "@EmployeeCode",
                                        NpgsqlTypes.NpgsqlDbType.Varchar);

                                    insertCommand.Parameters.Add(
                                        "@CmnDate",
                                        NpgsqlTypes.NpgsqlDbType.Timestamp);

                                    insertCommand.Parameters.Add(
                                        "@CmnTime",
                                        NpgsqlTypes.NpgsqlDbType.Timestamp);

                                    insertCommand.Parameters.Add(
                                        "@DeviceNo",
                                        NpgsqlTypes.NpgsqlDbType.Integer);

                                    insertCommand.Parameters.Add(
                                        "@Status",
                                        NpgsqlTypes.NpgsqlDbType.Varchar);

                                    insertCommand.Parameters.Add(
                                        "@CompanyId",
                                        NpgsqlTypes.NpgsqlDbType.Integer);

                                    insertCommand.Parameters.Add(
                                        "@BranchId",
                                        NpgsqlTypes.NpgsqlDbType.Integer);

                                    insertCommand.Parameters.Add(
                                        "@DeviceName",
                                        NpgsqlTypes.NpgsqlDbType.Varchar);

                                    insertCommand.Parameters.Add(
                                        "@AttendanceYearId",
                                        NpgsqlTypes.NpgsqlDbType.Integer);

                                    int insertedCount = 0;

                                    foreach (DataRow row in punches.Rows)
                                    {
                                        insertCommand.Parameters[
                                            "@EmployeeCode"].Value =
                                            row["EmployeeCode"];

                                        insertCommand.Parameters[
                                            "@CmnDate"].Value =
                                            Convert.ToDateTime(row["CmnDate"]);

                                        insertCommand.Parameters[
                                            "@CmnTime"].Value =
                                            Convert.ToDateTime(row["CmnTime"]);

                                        insertCommand.Parameters[
                                            "@DeviceNo"].Value =
                                            row["DeviceNo"] == DBNull.Value
                                            ? DBNull.Value
                                            : row["DeviceNo"];

                                        insertCommand.Parameters[
                                            "@Status"].Value = "0";

                                        insertCommand.Parameters[
                                            "@CompanyId"].Value =
                                            row["CompanyId"];

                                        insertCommand.Parameters[
                                            "@BranchId"].Value =
                                            row["BranchId"];

                                        insertCommand.Parameters[
                                            "@DeviceName"].Value =
                                            DBNull.Value;

                                        insertCommand.Parameters[
                                            "@AttendanceYearId"].Value =
                                            DBNull.Value;

                                        insertCommand.ExecuteNonQuery();
                                        insertedCount++;
                                    }

                                    WriteLog(logPath,
                                        "Records inserted before commit: " +
                                        insertedCount);
                                }

                                transaction.Commit();

                                WriteLog(logPath,
                                    "PostgreSQL transaction committed.");
                            }
                            catch
                            {
                                try
                                {
                                    transaction.Rollback();
                                }
                                catch (Exception rollbackException)
                                {
                                    WriteLog(logPath,
                                        "Rollback error: " +
                                        rollbackException.Message);
                                }

                                throw;
                            }
                        }
                    }

                    // Mark source records only after destination commit.
                    UpdateSourceFlags(
                        sourceConnection,
                        deviceLogTable,
                        punches,
                        logPath);

                    WriteLog(logPath, "Process completed successfully.");
                    //Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                WriteLog(logPath,
                    "ERROR: " + ex);

                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Press any key to exit.");
            //Console.ReadKey();
        }

        private static string GetDeviceLogTable(
            string prefix, DateTime tableDate)
        {
            if (string.IsNullOrWhiteSpace(prefix))
                throw new ArgumentException(
                    "Device log table prefix is missing.");

            string[] parts = prefix.Split('.');

            if (parts.Length != 3)
                throw new ArgumentException(
                    "TABLE_DEVICE_LOGS must contain database.schema.table.");

            foreach (string part in parts)
            {
                if (!Regex.IsMatch(part, @"^[A-Za-z0-9_]+$"))
                    throw new ArgumentException(
                        "Invalid device log table identifier.");
            }

            string tableName = parts[2] +
                tableDate.Month + "_" + tableDate.Year;

            return "[" + parts[0] + "].[" + parts[1] +
                "].[" + tableName + "]";
        }

        private static void UpdateSourceFlags(
            SqlConnection sourceConnection,
            string deviceLogTable,
            DataTable punches,
            string logPath)
        {
            DataTable processedRows = new DataTable();

            processedRows.Columns.Add(
                "UserId", typeof(string));

            processedRows.Columns.Add(
                "Logdate", typeof(DateTime));

            foreach (DataRow row in punches.Rows)
            {
                DataRow processedRow = processedRows.NewRow();

                processedRow["UserId"] =
                    Convert.ToString(
                        row["SourceUserId"],
                        CultureInfo.InvariantCulture);

                processedRow["Logdate"] =
                    Convert.ToDateTime(row["SourceLogDate"]);

                processedRows.Rows.Add(processedRow);
            }

            using (SqlCommand createCommand = new SqlCommand(@"
                CREATE TABLE #ProcessedPunches
                (
                    UserId nvarchar(100) NOT NULL,
                    Logdate datetime NOT NULL
                );", sourceConnection))
            {
                createCommand.ExecuteNonQuery();
            }

            using (SqlBulkCopy bulkCopy =
                new SqlBulkCopy(sourceConnection))
            {
                bulkCopy.DestinationTableName =
                    "#ProcessedPunches";

                bulkCopy.ColumnMappings.Add("UserId", "UserId");
                bulkCopy.ColumnMappings.Add("Logdate", "Logdate");

                bulkCopy.WriteToServer(processedRows);
            }

            string updateQuery = @"
                UPDATE D
                SET D.UpdateFlag = 1
                FROM " + deviceLogTable + @" D
                INNER JOIN #ProcessedPunches P
                    ON CONVERT(nvarchar(100), D.UserId) = P.UserId
                   AND D.Logdate = P.Logdate
                WHERE D.UpdateFlag <> 1;";

            using (SqlCommand updateCommand =
                new SqlCommand(updateQuery, sourceConnection))
            {
                updateCommand.CommandTimeout = 50000;

                int updatedCount = updateCommand.ExecuteNonQuery();

                WriteLog(logPath,
                    "Source UpdateFlag updated. Rows: " +
                    updatedCount);
            }

            using (SqlCommand dropCommand =
                new SqlCommand(
                    "DROP TABLE #ProcessedPunches;",
                    sourceConnection))
            {
                dropCommand.ExecuteNonQuery();
            }
        }

        private static void WriteLog(
            string logPath, string message)
        {
            try
            {
                string folder = Path.IsPathRooted(logPath)
                    ? logPath
                    : Path.Combine(
                        AppDomain.CurrentDomain.BaseDirectory,
                        logPath);

                Directory.CreateDirectory(folder);

                string fileName = Path.Combine(
                    folder,
                    "ESSLTOWETOS_" +
                    DateTime.Now.ToString("yyyyMMdd") +
                    ".log");

                string logMessage =
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                    " | " + message;

                Console.WriteLine(logMessage);

                File.AppendAllText(
                    fileName,
                    logMessage + Environment.NewLine);
            }
            catch (Exception logException)
            {
                Console.WriteLine(
                    "Logging error: " + logException.Message);
            }
        }
    }
}

