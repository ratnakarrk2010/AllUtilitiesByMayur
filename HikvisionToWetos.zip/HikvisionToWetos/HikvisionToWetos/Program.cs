﻿using System;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using ValidateLicence;

namespace HikvisionToWetos
{
    class Program
    {
        static void Main(string[] args)
        {
            string licenceEndDate = ConfigurationManager.AppSettings["LICENCE"];
            string tablenm = ConfigurationManager.AppSettings["HardwareDB"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(licenceEndDate));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }
            StringBuilder logs = new StringBuilder();
            StringBuilder errorLogs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    DataSet ds = new DataSet();
                    string queryString = "select Id , CONVERT(char(10), date,126)as date , convert(VARCHAR, datetime, 20)as datetime ,DeviceNo, status,E.CompanyId , E.BranchId ,device as DeviceName,null as AttendanceYear, null as Direction  from "+tablenm+" A join [WETOS_NEW].[dbo].Employee E  on A.ID COLLATE DATABASE_DEFAULT = E.EmployeeCode COLLATE DATABASE_DEFAULT WHERE status !='Z'";
                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.Fill(ds);
                    if(ds.Tables[0].Rows.Count > 0)
                    {
                        connection.Open();
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            string query = "insert into CommanData values('" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + ds.Tables[0].Rows[i][2] + "',1,'" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "','" + ds.Tables[0].Rows[i][7] + "',Null,Null)";
                            SqlCommand cmd = new SqlCommand(query, connection);
                            cmd.ExecuteNonQuery();

                            string query1 = "update "+ tablenm + " set status='Z' where ID='" + ds.Tables[0].Rows[i][0] + "' AND datetime='" + ds.Tables[0].Rows[i][2] + "'";
                            SqlCommand cmd1 = new SqlCommand(query1, connection);
                            cmd1.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                    Console.WriteLine("Data Transfer Successfully..!");
                }
            }

            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
        }
    }
}
