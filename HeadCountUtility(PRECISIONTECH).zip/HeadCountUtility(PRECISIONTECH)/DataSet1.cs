﻿namespace testApp
{


    partial class DataSet1
    {
    }
}
