﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.Reporting.WinForms;
using Microsoft.Office.Interop.Excel;
using System.IO;

namespace testApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DateTime date = System.DateTime.Now;
               //  DateTime date =Convert.ToDateTime("2022-10-10 00:00:00.000");
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string date1 =date.ToString("yyyy-MM-dd");
                SqlConnection connection = new SqlConnection(connectionString);
                var myDataSet = new DataSet();
                connection.Open();
                SqlCommand cmd = new SqlCommand("SP_EMPLOYEE_HEADCOUNT", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Fromdate", SqlDbType.DateTime).Value = date1;
                cmd.ExecuteNonQuery();
                System.Data.DataTable table = new System.Data.DataTable();
                table.TableName = "Companies";
                table.Load(cmd.ExecuteReader());
                connection.Close();
                Warning[] warnings;
                string[] streamIds;
                string mimeType = string.Empty;
                string encoding = string.Empty;
                string extension = string.Empty;

                ReportViewer viewer = new ReportViewer();
                ReportDataSource rprtDTSource = new ReportDataSource("DataSet1", table);
                viewer.LocalReport.DataSources.Add(rprtDTSource);
                viewer.ProcessingMode = ProcessingMode.Local;
                
              
                viewer.LocalReport.ReportPath = "Report3.rdlc";
                byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

                //using (System.IO.FileStream fs = new System.IO.FileStream("File.pdf", System.IO.FileMode.Create))
                //{
                //    fs.Write(bytes, 0, bytes.Length);
                //}
                string filePath = ConfigurationManager.AppSettings["FilePath"];
                string path = Path.Combine(filePath, "File.pdf");
                using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
                {
                    outputFileStream.Write(bytes, 0, bytes.Length);
                }







                //Application xlApp = new Application();
                //if (xlApp == null)
                //{
                //    return;
                //}
                //Workbook xlWorkBook;
                //Worksheet xlWorkSheet;
                //object misValue = System.Reflection.Missing.Value;
                //xlWorkBook = xlApp.Workbooks.Add(misValue);
                //xlWorkSheet = (Worksheet)xlWorkBook.Worksheets.get_Item(1);
                //xlWorkSheet.Cells[1, 1] = table.Rows[0];
                //xlWorkBook.SaveAs("D:\\csharp-Excel.xls", XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                //xlWorkBook.Close(true, misValue, misValue);
                //xlApp.Quit();
                //releaseObject(xlWorkSheet);
                //releaseObject(xlWorkBook);
                //releaseObject(xlApp);

                Console.WriteLine("File Created Successfully..!");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadKey();
            }
            
        }
        private static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
