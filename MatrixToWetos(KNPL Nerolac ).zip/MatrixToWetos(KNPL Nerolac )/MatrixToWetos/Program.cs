﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using ValidateLicence;

namespace MatrixToWetos
{
    class Program
    {
        static StringBuilder logBuilder = new StringBuilder("");
        static void Main(string[] args)
        {
            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            string connectionString1 = ConfigurationManager.AppSettings["connectionstring"];
            string DataSource = ConfigurationManager.AppSettings["DataSource"];
            string DBName = ConfigurationManager.AppSettings["DBName"];
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            SqlConnection connection1 = new SqlConnection(connectionString1);

            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            try
            {

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    connection1.Open();

                    //string query13 = "select EmployeeCode from Employee";
                    //SqlDataAdapter adapter13 = new SqlDataAdapter(query13, connection1);
                    //DataSet ds13 = new DataSet();
                    //adapter13.Fill(ds13);

                    //string query12 = "select CompanyId ,BranchId from Employee where EmployeeCode= '"+ ds13.Tables[0].Rows[0][0] + "' ";
                    //SqlDataAdapter adapter12 = new SqlDataAdapter(query12, connection1);
                    //DataSet ds12 = new DataSet();
                    //adapter12.Fill(ds12);




                    if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                    {
                        var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                        myFile.Close();
                    }
                    var fs = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                    using (StreamWriter writer = new StreamWriter(fs))
                    {
                        writer.WriteLine("Connection established successfully. "+DateTime.Now);
                        writer.Close();
                    }
                    Console.WriteLine("Connection established successfully.");
                    getMaxId();
                    //string query11 = "select count(*) from tbl_IndexNo";
                    //SqlDataAdapter adapter11 = new SqlDataAdapter(query11, connection);
                    //DataSet dsIndex1 = new DataSet();
                    //adapter11.Fill(dsIndex1);
                    if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) > 0 && Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) != 0)
                    //if (Convert.ToInt32(dsIndex1.Tables[0].Rows[0][0]) > 0 && Convert.ToInt32(dsIndex1.Tables[0].Rows[0][0]) != 0)
                    {
                       // getMaxId();
                        int indexno = Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]);
                        //string queryString = "select Usr.userid , convert(char(10), Trn.edatetime, 126),convert(varchar, Trn.edatetime, 126) ,Usr.ORGID ,Usr.BRCID,IndexNo from " + cosecDataSource + ".[COSEC].[dbo].[Mx_ATDEventTrn] Trn join " + cosecDataSource + ".[COSEC].[dbo].[Mx_UserMst] Usr on(Trn.UserId = Usr.UserId) where Usr.BRCID = 11 and Trn.IndexNo > " + indexno;
                        //string queryString = "select top(100) Usr.userid , convert(char(10), Trn.edatetime, 126),convert(varchar, Trn.edatetime, 126) as Edatetime,Emp.CompanyId ,Emp.BranchId,IndexNo from [COSEC].[dbo].[Mx_ATDEventTrn] Trn join [COSEC].[dbo].[Mx_UserMst] Usr on(Trn.UserId = Usr.UserId) join " + DataSource + ".[Contrator_new].[dbo].[Employee] Emp on(Emp.employeecode = Usr.UserId) where Usr.BRCID = 11 and Trn.IndexNo > " + indexno + "order by Trn.IndexNo";
                        string queryString = "select Usr.userid , convert(char(10), Trn.edatetime, 126),convert(varchar, Trn.edatetime, 126) as Edatetime,IndexNo from [COSEC].[dbo].[Mx_ATDEventTrn] Trn join [COSEC].[dbo].[Mx_UserMst] Usr on(Trn.UserId = Usr.UserId) where Usr.BRCID = 11 and Trn.IndexNo > " + indexno + "order by Trn.IndexNo";
                      //  Console.WriteLine("Data Bind");
                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                        adapter.SelectCommand.CommandTimeout = 300;
                        adapter.Fill(ds);
                    //    Console.WriteLine("Data Bind1");
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                            {
                                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                                myFile.Close();
                            }
                            var fs1 = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                            using (StreamWriter writer = new StreamWriter(fs1))
                            {
                                writer.WriteLine("Data fetch from Mx_ATDEventTrn. " + DateTime.Now);
                                writer.Close();
                            }
                            Console.WriteLine("Data fetch from Mx_ATDEventTrn");
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string query = "select CompanyId ,BranchId from Employee where EmployeeCode='"+ ds.Tables[0].Rows[i][0] + "'";
                                SqlDataAdapter adapter1 = new SqlDataAdapter(query, connection1);
                                DataSet ds11 = new DataSet();
                                //adapter1.SelectCommand.CommandTimeout = 300;
                                adapter1.Fill(ds11);
                            //    Console.WriteLine("Data fetch from Employee");
                                if(ds11.Tables[0].Rows.Count > 0 )
                                {
                                    //using (SqlCommand cmd = new SqlCommand("INSERT INTO " + cosecDataSource + ".[Contrator_new].[dbo].[CommanData] (EmployeeCode,CmnDate,CmnTime,DeviceNo,Status,CompanyId,BranchId,DeviceName,AttendanceYearId) values('" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + ds.Tables[0].Rows[i][2] + "', 1,null,'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "',null,null)", connection1))
                                    //using (SqlCommand cmd = new SqlCommand("INSERT INTO [Contrator_new].[dbo].[CommanData] (EmployeeCode,CmnDate,CmnTime,DeviceNo,Status,CompanyId,BranchId,DeviceName,AttendanceYearId) values('" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + ds.Tables[0].Rows[i][2] + "', 1,null,'" + ds11.Tables[0].Rows[0][0] + "','" + ds11.Tables[0].Rows[0][1] + "',null,null)", connection1))
                                    using (SqlCommand cmd = new SqlCommand("INSERT INTO "+ DBName + ".[dbo].[CommanData] (EmployeeCode,CmnDate,CmnTime,DeviceNo,Status,CompanyId,BranchId,DeviceName,AttendanceYearId) values('" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + ds.Tables[0].Rows[i][2] + "', 1,null,'" + ds11.Tables[0].Rows[0][0] + "','" + ds11.Tables[0].Rows[0][1] + "',null,null)", connection1))
                                    {
                                        cmd.ExecuteNonQuery();
                                        //    Console.WriteLine("Data inserted");
                                        //string query1 = "update tbl_IndexNo set IndexNo='" + ds.Tables[0].Rows[i][3] + "'";
                                        string query1 = "update GlobalSetting set SettingValue='" + ds.Tables[0].Rows[i][3] + "' where SettingText='SQLIndexNo'";
                                        SqlCommand cmd1 = new SqlCommand(query1, connection1);
                                        cmd1.ExecuteNonQuery();
                                    //    Console.WriteLine("Data updated");
                                    }
                                }
                                
                            }
                            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                            {
                                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                                myFile.Close();
                            }
                            var fs2 = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                            using (StreamWriter writer = new StreamWriter(fs2))
                            {
                                writer.WriteLine("Data inserted successfully. " + DateTime.Now);
                                writer.Close();
                            }
                            Console.WriteLine("Data inserted successfully");
                            connection.Close();
                        }
                    }
                    else
                    {
                        //connection.Open();
                        if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                        {
                            var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                            myFile.Close();
                        }
                        var fs2 = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                        using (StreamWriter writer = new StreamWriter(fs2))
                        {
                            writer.WriteLine("Connection established successfully. " + DateTime.Now);
                            writer.Close();
                        }
                        Console.WriteLine("Connection established successfully..!");
                        //string queryString1 = "select Usr.userid , convert(char(10), Trn.edatetime, 126),convert(varchar, Trn.edatetime, 126) ,Usr.ORGID ,Usr.BRCID,IndexNo from " + cosecDataSource + ".[COSEC].[dbo].[Mx_ATDEventTrn] Trn join " + cosecDataSource + ".[COSEC].[dbo].[Mx_UserMst] Usr on(Trn.UserId = Usr.UserId) where Usr.BRCID = 11";
                        //string queryString1 = "select top(100) Usr.userid , convert(char(10), Trn.edatetime, 126) as Edatetime,convert(varchar, Trn.edatetime, 126) ,Emp.CompanyId ,Emp.BranchId,IndexNo from [COSEC].[dbo].[Mx_ATDEventTrn] Trn join [COSEC].[dbo].[Mx_UserMst] Usr on(Trn.UserId = Usr.UserId) join " + DataSource + ".[Contrator_new].[dbo].[Employee] Emp on(Emp.employeecode = Usr.UserId)where Usr.BRCID = 11 order by Trn.IndexNo";
                        string queryString1 = "select Usr.userid , convert(char(10), Trn.edatetime, 126) as Edatetime,convert(varchar, Trn.edatetime, 126),IndexNo from [COSEC].[dbo].[Mx_ATDEventTrn] Trn join [COSEC].[dbo].[Mx_UserMst] Usr on(Trn.UserId = Usr.UserId) where Usr.BRCID = 11 order by Trn.IndexNo";
                        SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                        adapter1.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        {

                            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                            {
                                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                                myFile.Close();
                            }
                            var fs3 = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                            using (StreamWriter writer = new StreamWriter(fs3))
                            {
                                writer.WriteLine("Data fetch from Mx_ATDEventTrn. " + DateTime.Now);
                                writer.Close();
                            }
                            Console.WriteLine("Data fetch from Mx_ATDEventTrn");
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string query = "select CompanyId ,BranchId from Employee where EmployeeCode='" + ds.Tables[0].Rows[i][0] + "'";
                                SqlDataAdapter adapter11 = new SqlDataAdapter(query, connection1);
                                DataSet ds11 = new DataSet();
                                adapter11.Fill(ds11);
                                if (ds11.Tables[0].Rows.Count > 0)
                                {
                                    //using (SqlCommand cmd = new SqlCommand("INSERT INTO " + cosecDataSource + ".[Contrator_new].[dbo].[CommanData] (EmployeeCode,CmnDate,CmnTime,DeviceNo,Status,CompanyId,BranchId,DeviceName,AttendanceYearId) values('" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + ds.Tables[0].Rows[i][2] + "', 1,null,'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "',null,null)", connection1))
                                    using (SqlCommand cmd = new SqlCommand("INSERT INTO " + DBName + ".[dbo].[CommanData] (EmployeeCode,CmnDate,CmnTime,DeviceNo,Status,CompanyId,BranchId,DeviceName,AttendanceYearId) values('" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + ds.Tables[0].Rows[i][2] + "', 1,null,'" + ds11.Tables[0].Rows[0][0] + "','" + ds11.Tables[0].Rows[0][1] + "',null,null)", connection1))
                                    {
                                        cmd.ExecuteNonQuery();
                                        // getMaxId();
                                        //if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) == 0)
                                        //{

                                        //    //string query1 = "insert into tbl_IndexNo values('" + ds.Tables[0].Rows[i][3] + "')";
                                        //    string query1 = "insert into GlobalSetting values('SQLIndexNo','" + ds.Tables[0].Rows[i][3] + "',1)";
                                        //    SqlCommand cmd1 = new SqlCommand(query1, connection);
                                        //    cmd1.ExecuteNonQuery();
                                        //}
                                        //else
                                        //{
                                            //string query1 = "update tbl_IndexNo set IndexNo='" + ds.Tables[0].Rows[i][3] + "'";
                                            string query1 = "update GlobalSetting set SettingValue='" + ds.Tables[0].Rows[i][3] + "' where SettingText='SQLIndexNo'";
                                            SqlCommand cmd1 = new SqlCommand(query1, connection1);
                                            cmd1.ExecuteNonQuery();
                                        //}
                                    }
                                }
                                    
                            }
                            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                            {
                                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                                myFile.Close();
                            }
                            var fs1 = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                            using (StreamWriter writer = new StreamWriter(fs1))
                            {
                                writer.WriteLine("Data inserted successfully. " + DateTime.Now);
                                writer.Close();
                            }
                            Console.WriteLine("Data inserted successfully");
                        }
                        connection.Close();
                        connection1.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                {
                    var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                    myFile.Close();
                }
                var fs = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.WriteLine(ex);
                    writer.Close();
                }
               // LogInfo(ex.Message);
                Console.WriteLine(ex.Message);
                //Console.ReadKey();
            }
            finally
            {
                if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
                {
                    var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                    myFile.Close();
                }
                var fs = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.WriteLine("successfull. " + DateTime.Now);
                    writer.Close();
                }
               // LogInfo("data transfer failed");
                logBuilder.AppendLine("successfull");
            }
        }
        static DataSet dsmaxId = new DataSet();
        static DataTable getMaxId()
        {
           // Console.WriteLine("Inside getMaxId");
            string connectionString = ConfigurationManager.AppSettings["connectionstring"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                //   Console.WriteLine("connection open");
                //string query11 = "select isnull(max(IndexNo),0) from tbl_IndexNo";
                string query11 = "select isnull(max(SettingValue),0) from GlobalSetting where SettingText = 'SQLIndexNo'";
                
                SqlDataAdapter adapter11 = new SqlDataAdapter(query11, connection);
                dsmaxId.Clear();
                adapter11.Fill(dsmaxId);
                var id = dsmaxId.Tables[0].Rows[0][0];
                connection.Close();
             //   Console.WriteLine("connection close");
                return dsmaxId.Tables[0];
            }
        }
        public static void LogInfo(string logMessage)
        {
            //var serverPath = AppDomain.CurrentDomain.BaseDirectory;
            //var log = serverPath + "\\" + "LogFile";
            //if (System.IO.Directory.Exists(log))
            //{
            //    System.IO.Directory.CreateDirectory(log);
            //}
            //string path = log + "\\Logs" + DateTime.Today.ToString("ddMMyyyy") + ".txt";
            
            //if (!File.Exists(path))
            //{
            //    var myFile = File.Create(path);
            //    myFile.Close();
            //}
            //var fs = File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
            //using (StreamWriter writer = new StreamWriter(fs))
            //{
            //    writer.WriteLine(logMessage);
            //    writer.Close();
            //}

            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
            {
                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                myFile.Close();
            }
            var fs = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.WriteLine("Connection established successfully. " + DateTime.Now);
                writer.Close();
            }
        }
    }
}
