﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using ValidateLicence;

namespace PiramalFtpUtility
{
    class Program
    {
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            DateTime logDateToFetch = DateTime.Now.AddDays(-logDateInDays);
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }
            StringBuilder logs = new StringBuilder();
            StringBuilder errorLogs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            
            DateTime today1 = DateTime.Now;
            string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            try
            {
                DataTable tblDeviceLogs = getData(logs, logDateToFetch);
                foreach (DataRow row in tblDeviceLogs.Rows)
                {
                    IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                    fileContents.AppendLine(string.Join(",", fields));
                }

                string fileName_Prefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];
                string fileName_DateFormat = ConfigurationManager.AppSettings["FILENAME_DATE_FORMAT"];
                string fileName = fileName_Prefix + logDateToFetch.ToString(fileName_DateFormat) + ".txt";
                
                File.WriteAllText(localFolderPath + @"\" + fileName, fileContents.ToString());
                logs.AppendLine("Locally file '" + fileName + "' created successfully");
                Console.WriteLine("Locally file '" + fileName + "' created successfully");

                uploadFilesToFTP(fileName, fileContents.ToString(), logs);

            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
            }
        }
        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            try
            {
                Console.WriteLine("Inside getdata method");
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    Console.WriteLine("Connection established successfully..!");
                    using (SqlCommand cmd = new SqlCommand("Tas", connection))
                    {
                        string today = logDateToFetch.ToString("yyyy-MM-dd");
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@TasDate", SqlDbType.VarChar).Value = today;
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        adapter.SelectCommand = cmd;
                        Console.WriteLine("Procedure call..!");
                        cmd.CommandTimeout = 50000; 
                        adapter.Fill(deviceLogs);
                        Console.WriteLine("Data fetched successfully");
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            return deviceLogs.Tables[0];
        }
        static void uploadFilesToFTP(string fileName, string fileContents, StringBuilder logs)
        {
            string host = ConfigurationManager.AppSettings["HOST"];
            if (string.IsNullOrEmpty(host) == false)
            {
                try
                {
                    string username = ConfigurationManager.AppSettings["USERNAME"];
                    string password = ConfigurationManager.AppSettings["PASSWORD"];
                    string ftpDestinationFolder = ConfigurationManager.AppSettings["FTP_DESTINATION_FOLDER"];
                    int port = Convert.ToInt32(ConfigurationManager.AppSettings["PORT"]);
                    string ftpFilePath = "ftp://" + host + ":" + port + "//" + ftpDestinationFolder + "/" + fileName;
                    FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpFilePath);
                    request.Method = WebRequestMethods.Ftp.UploadFile;
                    request.Credentials = new NetworkCredential(username, password);
                    byte[] bytesFileContents = Encoding.Default.GetBytes(fileContents);
                    request.ContentLength = fileContents.Length;


                    request.KeepAlive = true;
                    request.UsePassive = true;
                    request.Timeout = 300000000;


                    using (Stream requestStream = request.GetRequestStream())
                    {
                        requestStream.Write(bytesFileContents, 0, bytesFileContents.Length);
                    }
                    using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                    {
                        logs.AppendLine("Uploaded file '" + fileName + "' successfully");
                        Console.WriteLine("Uploaded file '" + fileName + "' successfully");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                }
            }
            else
            {
                logs.AppendLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
                Console.WriteLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
            }
        }
    }
}
