﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using ValidateLicence;
using System.Threading.Tasks;

namespace SFTPUtility
{
    class Program
    {
        static void Main(string[] args)
        {

            string licenceEndDate = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(licenceEndDate));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }

            StringBuilder logs = new StringBuilder();
            StringBuilder errorLogs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            string filenamePrefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];

            try
            {
                List<FileDataModel> FetchedData = new List<FileDataModel>();

                DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);

                DataTable tblDeviceLogs = getData(logs, logDateToFetch);

                var serverPath = AppDomain.CurrentDomain.BaseDirectory;
                string filename = filenamePrefix + logDateToFetch.ToString("ddMMyyyy") + ".txt";
                string dir = serverPath + "Employee Punch Data\\";
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                string path = serverPath + "Employee Punch Data\\" + filename;
                var myFile = System.IO.File.Create(path);
                myFile.Close();
                string message = "";
                message += String.Format("{0},{1},{2},{3},{4}", "PS NO.", "DATE", "TIME", "TERMINAL ID", "P10/P20");

                foreach (DataRow row in tblDeviceLogs.Rows)
                {


                    FileDataModel dataModel = new FileDataModel();
                    dataModel.UserId = row.ItemArray[0].ToString();
                    dataModel.LogDate = Convert.ToDateTime(row.ItemArray[1]);
                    dataModel.DeviceId = Convert.ToString(row.ItemArray[2]);
                    FetchedData.Add(dataModel);
                }

                var employeeDataGroup = FetchedData.GroupBy(x => x.UserId).ToList();

                foreach (var empGroup in employeeDataGroup)
                {
                    var firstIn = empGroup.OrderBy(x => x.LogDate).FirstOrDefault();
                    var lastOut = empGroup.OrderByDescending(x => x.LogDate).FirstOrDefault();

                    
                    message += Environment.NewLine;
                    message += String.Format("{0},{1},{2},{3},{4}", empGroup.Key, firstIn.LogDate.ToString("yyyyMMdd"), firstIn.LogDate.ToString("HH:mm:ss"), firstIn.DeviceId, "P10");
                    
                    message += Environment.NewLine;
                    message += String.Format("{0},{1},{2},{3},{4}", empGroup.Key, lastOut.LogDate.ToString("yyyyMMdd"), lastOut.LogDate.ToString("HH:mm:ss"), lastOut.DeviceId, "P20");
                  
                }

                var fs = System.IO.File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.WriteLine(message);
                    writer.Close();
                }

                uploadFilesToSFTP(path, fileContents.ToString(), logs);
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
            //finally
            //{
            //    File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
            //}
        }

        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            try
            {
               
                string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
                string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string logDateTime = ConfigurationManager.AppSettings["LOG_DATE_TIME"];
                string logDateTimeCondition = ConfigurationManager.AppSettings["LOG_DATE_TIME_CONDITION"];
                string direction_in = ConfigurationManager.AppSettings["DIRECTION_IN"];
                string direction_out = ConfigurationManager.AppSettings["DIRECTION_OUT"];
                string direction_altInOut = ConfigurationManager.AppSettings["DIRECTION_ALT_IN_OUT"];
                if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);
                string LogTableName = ConfigurationManager.AppSettings["LogTableName"];

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string queryString = "select UserId, LogDate, DeviceId from " + tblDeviceLogs + " where LogDate >= '" + logDateToFetch.ToString("yyyy-MM-dd") + "' and LogDate < '" + logDateToFetch.AddDays(1).ToString("yyyy-MM-dd") + "'";
                  

                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);

                    adapter.Fill(deviceLogs, "tblDeviceLogs");
                }

            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
            return deviceLogs.Tables[0];
        }

        static void uploadFilesToSFTP(string filePath, string fileContents, StringBuilder logs)
        {
            try
            {
                var host = ConfigurationManager.AppSettings["HOST"]; //"whateverthehostis.com";
                var port = 22; //Convert.ToInt32(ConfigurationManager.AppSettings["PORT"]);
                var username = ConfigurationManager.AppSettings["USERNAME"]; //"username";
                var password = ConfigurationManager.AppSettings["PASSWORD"];  //"passw0rd";

                // path for file you want to upload
                //var uploadFile = @"c:yourfilegoeshere.txt";
                var uploadFile = filePath;

                using (var client = new SftpClient(host, port, username, password))
                {
                    client.Connect();
                    if (client.IsConnected)
                    {
                        //Debug.WriteLine("I'm connected to the client");

                        using (var fileStream = new FileStream(uploadFile, FileMode.Open))
                        {
                            //client.CreateDirectory();
                            client.BufferSize = 4 * 1024; // bypass Payload error large files

                            client.UploadFile(fileStream, Path.GetFileName(uploadFile)); //working, stores in the User folder 

                            //string ftpDestinationFolder = ConfigurationManager.AppSettings["FTP_DESTINATION_FOLDER"];
                            //string ftpFilePath = "ftp://" + host + ftpDestinationFolder + "/" + Path.GetFileName(uploadFile);
                            //client.UploadFile(fileStream, ftpFilePath);
                        }
                    }
                    else
                    {
                        Console.WriteLine("I couldn't connect");
                    }
                }
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class FileDataModel
    {
        public string UserId { get; set; }
        public DateTime LogDate { get; set; }
      //  public string LogTime { get; set; }
        public string DeviceId { get; set; }
    }
}
