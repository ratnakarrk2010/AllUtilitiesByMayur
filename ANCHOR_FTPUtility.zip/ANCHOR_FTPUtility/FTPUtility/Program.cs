﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using ValidateLicence;


/*using Renci.SshNet;*/ //210322

namespace FTPUtility
{
    class Program
    {
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            //var isPCLicenceOK = true;
            //var custId = "eviska";
            //isPCLicenceOK = VerifyDetails.ComparePCLicense(toDate, custId);
            //to check for licence
            
            
            
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }
            //if(isPCLicenceOK == false)
            //{
            //    Console.WriteLine("Not Valid User");
            //    Console.ReadKey();
            //    return;
            //}

            StringBuilder logs = new StringBuilder();
            StringBuilder errorLogs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            string timeEntryFormat = ConfigurationManager.AppSettings["TIME_ENTRY_DATE_FORMAT"];
            string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            string org_code = ConfigurationManager.AppSettings["ORGCODE"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";

            try
            {

                DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);
                //DateTime logDateToFetch = DateTime.Now;
                 DataTable tblDeviceLogs = getData(logs, logDateToFetch);
                 tblDeviceLogs.Columns.Remove("LOGID");
                
                string[] Headerfields = new string[3] { "EMPLOYEE_CODE", "PUNCH_TIME_STAMP", "ORG_CODE" };
                fileContents.AppendLine(string.Join("|", Headerfields));
                tblDeviceLogs.Columns.Add("ORG_CODE");
                foreach (DataRow row in tblDeviceLogs.Rows)
                {
                    row["ORG_COdE"] = org_code;
                    IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                    fileContents.AppendLine(string.Join("|", fields));
                }

                string fileName_Prefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];
                string fileName_DateFormat = ConfigurationManager.AppSettings["FILENAME_DATE_FORMAT"];
                string fileName = fileName_Prefix + logDateToFetch.ToString(fileName_DateFormat) + ".csv";
               
                File.WriteAllText(localFolderPath + @"\" + fileName, fileContents.ToString());
                logs.AppendLine("Locally file '" + fileName + "' created successfully");
                Console.WriteLine("Locally file '" + fileName + "' created successfully");

               
          
                uploadFilesToFTP(fileName, fileContents.ToString(), logs);

            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
                
            }
            finally
            {
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
            }
        }

        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            try
            {
                string tblDevice = ConfigurationManager.AppSettings["TABLE_DEVICE"];
                string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
                string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string logDateTime = ConfigurationManager.AppSettings["LOG_DATE_TIME"];
                string logDateTimeCondition = ConfigurationManager.AppSettings["LOG_DATE_TIME_CONDITION"];
                string direction_in = ConfigurationManager.AppSettings["DIRECTION_IN"];
                string direction_out = ConfigurationManager.AppSettings["DIRECTION_OUT"];
                string direction_altInOut = ConfigurationManager.AppSettings["DIRECTION_ALT_IN_OUT"];
                string deviceid1 = ConfigurationManager.AppSettings["DEVICEID"];
                string FTPTABLE = ConfigurationManager.AppSettings["FTPTABLE"];
                
                int id = 0;
                if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();// open the database connection 
                    string query11 = "select Name,Id from "+ FTPTABLE + "";
                    SqlDataAdapter adapter11 = new SqlDataAdapter(query11, connection);
                    DataSet dsIndex1 = new DataSet();
                    adapter11.Fill(dsIndex1);
                    
                    if (dsIndex1.Tables[0].Rows.Count > 0)
                    {
                        id = Convert.ToInt32(dsIndex1.Tables[0].Rows[0][1]);
                        string tblname = dsIndex1.Tables[0].Rows[0][0].ToString();
                        if (tblname != tblDeviceLogs)
                        {
                            string query1 = "update "+ FTPTABLE + " set Id='" + 0 + "',Name='" + tblDeviceLogs + "' ";
                            SqlCommand cmd1 = new SqlCommand(query1, connection);
                            cmd1.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        string query1 = "insert into "+ FTPTABLE + " values('" + "" + "','" + tblDeviceLogs + "')";
                        SqlCommand cmd1 = new SqlCommand(query1, connection);
                        cmd1.ExecuteNonQuery();

                        string query = "select Name,Id from "+ FTPTABLE + "";
                        SqlDataAdapter adapter1 = new SqlDataAdapter(query, connection);
                        DataSet dsIndex = new DataSet();
                        adapter1.Fill(dsIndex);
                        id = Convert.ToInt32(dsIndex.Tables[0].Rows[0][1]);
                    }

                  
                    string[] device_ids = deviceid1.Split(',');
                    foreach(string deviceid in device_ids)
                    {
                        //string queryString = "Select EmployeeCode,TimeEvent,convert(varchar,TimeEntry, 126)+ '.000+00:00' "
                        //string queryString = "Select DISTINCT LOGID AS LOGID,case when LEN(EmployeeCode) =1 then 'A0000'+EmployeeCode when LEN(EmployeeCode) =2 then 'A000'+EmployeeCode when LEN(EmployeeCode) =3 then 'A00'+EmployeeCode when LEN(EmployeeCode) =4 then 'A0'+EmployeeCode else 'A'+EmployeeCode end,"
                        string queryString = "SELECT DISTINCT LOGID AS LOGID,CASE WHEN LEN(EmployeeCode) = 1 THEN 'A0000' + EmployeeCode WHEN LEN(EmployeeCode) = 2 THEN 'A000' + EmployeeCode WHEN LEN(EmployeeCode) = 3 THEN 'A00' + EmployeeCode WHEN LEN(EmployeeCode) = 4 THEN 'A0' + EmployeeCode WHEN LEN(EmployeeCode) = 5 THEN 'A' + EmployeeCode ELSE EmployeeCode  end,"
                                    //+ "CONVERT(varchar,TimeEntry,3)+ ' '  + convert(VARCHAR(5), TimeEntry,14) "
                                    + "FORMAT(TimeEntry,'MM-dd-yyyy')+ ' '  + convert(VARCHAR, TimeEntry,108) "
                                            + "from("
                                            + "Select DL.DeviceLogId AS LOGID,DL.UserID as EmployeeCode, Min(DL.LOgdate) as TimeEntry, 'IN' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId "
                        + "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_altInOut + "' and DL.DeviceLogId >'" + id + "' and  DL.DeviceId ='" + deviceid + "' ";
                        //if (string.IsNullOrEmpty(logDateTime) == false)
                        //{
                        //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                        //}
                        queryString += "group by DL.UserID, Cast(DL.LogDate as date),DL.DeviceLogId "
                                        + "Union "
                                        + "Select DL.DeviceLogId AS LOGID,DL.UserID as EmployeeCode, Min(DL.LOgdate) as TimeEntry, 'IN' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId "
                        + "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_in + "'and DL.DeviceLogId >'" + id + "' and  DL.DeviceId ='" + deviceid + "' ";
                        //if (string.IsNullOrEmpty(logDateTime) == false)
                        //{
                        //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                        //}
                        queryString += "group by DL.UserID, Cast(DL.LogDate as date),DL.DeviceLogId "
                                        + "Union "
                                        + "Select DL.DeviceLogId AS LOGID,DL.UserID as EmployeeCode, Max(DL.LOgdate) as TimeEntry, 'OUT' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId "
                        + "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_altInOut + "' and DL.DeviceLogId >'" + id + "' and  DL.DeviceId ='" + deviceid + "' ";
                        //if (string.IsNullOrEmpty(logDateTime) == false)
                        //{
                        //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                        //}
                        queryString += "group by DL.UserID, Cast(DL.LogDate as date),DL.DeviceLogId "
                                        + "Union "
                                        + "Select DL.DeviceLogId AS LOGID,DL.UserID as EmployeeCode, Max(DL.LOgdate) as TimeEntry, 'OUT' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId "
                        + "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_out + "' and DL.DeviceLogId >'" + id + "' and  DL.DeviceId ='" + deviceid + "'";
                        //if (string.IsNullOrEmpty(logDateTime) == false)
                        //{
                        //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                        //}
                        queryString += "group by DL.UserID, Cast(DL.LogDate as date),DL.DeviceLogId"
                                        + ") as tblDeviceLogs";
                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);

                        DataSet copyDataSet = new DataSet();
                        adapter.Fill(copyDataSet, "tblDeviceLogs");
                        //adapter.Fill(deviceLogs, "tblDeviceLogs");
                        deviceLogs.Merge(copyDataSet);
                    }

                    

                    if (deviceLogs.Tables[0].Rows.Count!=0)
                    {
                        string lastColvalue = deviceLogs.Tables[0].Rows[deviceLogs.Tables[0].Rows.Count - 1]["LOGID"].ToString();
                        string query1 = "update "+ FTPTABLE + " set Id='" + lastColvalue + "',Name='" + tblDeviceLogs + "' ";
                        SqlCommand cmd1 = new SqlCommand(query1, connection);
                        cmd1.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            return deviceLogs.Tables[0];
        }

        static void uploadFilesToFTP(string fileName, string fileContents, StringBuilder logs)
        {
            string host = ConfigurationManager.AppSettings["HOST"];
            if (string.IsNullOrEmpty(host) == false)
            {
                try
                {
                    string username = ConfigurationManager.AppSettings["USERNAME"];
                    string password = ConfigurationManager.AppSettings["PASSWORD"];
                    string ftpDestinationFolder = ConfigurationManager.AppSettings["FTP_DESTINATION_FOLDER"];
                    int port = Convert.ToInt32( ConfigurationManager.AppSettings["PORT"]);
                    string ftpFilePath = "ftp://" + host + ":"+port+ "//" +ftpDestinationFolder + "/" + fileName;
                   // string ftpFilePath = "ftp://" + host + ftpDestinationFolder + "/" + fileName;
                    FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpFilePath);
                    request.Method = WebRequestMethods.Ftp.UploadFile;
                    request.Credentials = new NetworkCredential(username, password);
                    byte[] bytesFileContents = Encoding.Default.GetBytes(fileContents);
                    request.ContentLength = fileContents.Length;

                   
                    request.KeepAlive = true;
                    request.UsePassive = true;
                    request.Timeout = 300000000;
                    //string To = ftpFilePath;

                    //using (WebClient client = new WebClient())
                    //{
                    //    client.Credentials = new NetworkCredential(username, password);
                    //    client.UploadFile(To, WebRequestMethods.Ftp.UploadFile, From);
                    //}

                    //using (SftpClient client = new SftpClient(host, port, username, password))
                    //{
                    //    client.Connect();
                    //    client.ChangeDirectory(ftpFilePath);
                    //    using (FileStream fs = new FileStream(source, FileMode.Open))
                    //    {
                    //        client.BufferSize = 4 * 1024;
                    //        client.UploadFile(fs, Path.GetFileName(source));
                    //    }
                    //}


                    using (Stream requestStream = request.GetRequestStream())
                    {
                        requestStream.Write(bytesFileContents, 0, bytesFileContents.Length);
                    }
                    using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                    {
                        logs.AppendLine("Uploaded file '" + fileName + "' successfully");
                        Console.WriteLine("Uploaded file '" + fileName + "' successfully");
                    }






                    // FileStream fileStream = File.Open(fileName, FileMode.Open, FileAccess.Read);
                    //Stream requestStream = request.GetRequestStream();
                    //requestStream.Write(bytesFileContents, 0, bytesFileContents.Length);
                    //fileStream.CopyToAsync(requestStream);

                    // FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                    //Console.WriteLine($"Upload File Complete, status {response.StatusDescription}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                }

            }
            else
            {
                logs.AppendLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
                Console.WriteLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
            }
        }

        
    }
    //class BioMetricsData
    //{
    //    string employeeCode = string.Empty;
    //    DateTime timeEntry;
    //    string timeEvent = string.Empty;

    //    public string EmployeeCode { get => employeeCode; set => employeeCode = value; }
    //    public DateTime TimeEntry { get => timeEntry; set => timeEntry = value; }
    //    public string TimeEvent { get => timeEvent; set => timeEvent = value; }
    //}
    //    {
    //    List<BioMetricsData> bioMetricDataList = (from DL in dbEntity.DeviceLogs
    //                                              join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                              where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "altinout"
    //                                              group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                              select new BioMetricsData
    //                                              {
    //                                                  EmployeeCode = g.Key.UserId,
    //                                                  TimeEntry = g.Min(p => p.LogDate),
    //                                                  TimeEvent = "IN"
    //                                              }).Union
    //                                                            (from DL in dbEntity.DeviceLogs
    //                                                             join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                                             where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "in"
    //                                                             group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                                             select new BioMetricsData
    //                                                             {
    //                                                                 EmployeeCode = g.Key.UserId,
    //                                                                 TimeEntry = g.Min(p => p.LogDate),
    //                                                                 TimeEvent = "IN"
    //                                                             }).Union
    //                                                            (from DL in dbEntity.DeviceLogs
    //                                                             join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                                             where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "altinout"
    //                                                             group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                                             select new BioMetricsData
    //                                                             {
    //                                                                 EmployeeCode = g.Key.UserId,
    //                                                                 TimeEntry = g.Max(p => p.LogDate),
    //                                                                 TimeEvent = "OUT"
    //                                                             }).Union
    //                                                                (from DL in dbEntity.DeviceLogs
    //                                                                 join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                                                 where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "out"
    //                                                                 group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                                                 select new BioMetricsData
    //                                                                 {
    //                                                                     EmployeeCode = g.Key.UserId,
    //                                                                     TimeEntry = g.Max(p => p.LogDate),
    //                                                                     TimeEvent = "OUT"
    //                                                                 }).OrderBy(g => g.EmployeeCode).ToList<BioMetricsData>();
    //}


    
}


