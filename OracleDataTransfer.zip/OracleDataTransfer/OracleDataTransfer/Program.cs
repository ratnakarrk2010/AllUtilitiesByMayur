﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OracleClient;
using System.Configuration;
using System.Data;
using System.IO;
using ValidateLicence;

namespace OracleDataTransfer
{
    class Program
    {
        static StringBuilder logBuilder = new StringBuilder("");
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            try
            {
                Console.WriteLine("Inside method.");
                string sourceConnectionString = ConfigurationManager.AppSettings["connectionstring"];
                string destinationConnectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                // SqlConnection sourceConnection = new SqlConnection(sourceConnectionString);
                Console.WriteLine("Inside method1.");
                OracleConnection sourceConnection = new OracleConnection(sourceConnectionString);
                if (sourceConnection.State != ConnectionState.Open)
                    sourceConnection.Open();
                logBuilder.AppendLine("Oracle Connection established successfully with source.");
                Console.WriteLine("Oracle Connection established successfully. " + sourceConnection.ServerVersion);
                OracleConnection destinationConnection = new OracleConnection(destinationConnectionString);
                //  SqlConnection destinationConnection = new SqlConnection(destinationConnectionString);
                if (destinationConnection.State != ConnectionState.Open)
                    destinationConnection.Open();
                logBuilder.AppendLine("Oracle Connection established successfully with destination.");
                Console.WriteLine("Oracle Connection established successfully. " + destinationConnection.ServerVersion);
                TransferData(sourceConnection, destinationConnection);
                sourceConnection.Close();
                destinationConnection.Close();
                Console.WriteLine("Data transfer completed successfully.");
                LogInfo(logBuilder);
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred during data transfer: " + ex.Message);
                Console.ReadKey();
            }
        }
        static DataSet dsmaxId = new DataSet();
        static void TransferData(OracleConnection sourceConnection, OracleConnection destinationConnection)
        //  static void TransferData(SqlConnection sourceConnection, SqlConnection destinationConnection)
        {
            Console.WriteLine("inside transfer data method.");
            string destinationTableName = ConfigurationManager.AppSettings["DestinationTableName"];
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOGDATE_IN_DAYS"]);
            DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);
            getIndexNo(sourceConnection);
            string selectQuery = "select Trn.UserID as EID,usr.Name AS NAME ,trn as RFID_VALUE,trn.Edatetime as PUNCH_DATETIME,trn.MID AS TERMINAL_SL,1 AS STATUS,Trn.IndexNo from C##ACTA.MX_ACSEVENTTRN Trn join C##ACTA.Mx_UserMst usr on(usr.userid = trn.UserID) where Trn.IndexNo > '" + dsmaxId.Tables[0].Rows[0][0] + "' and Edatetime >= '" + logDateToFetch.ToString("dd-MM-yy") + "' and Edatetime < '" + logDateToFetch.AddDays(1).ToString("dd-MM-yy") + "'";
            OracleDataAdapter oracleDataAdapter = new OracleDataAdapter(selectQuery, sourceConnection);
            //  SqlDataAdapter oracleDataAdapter = new SqlDataAdapter(selectQuery, sourceConnection);
            DataSet dataSet = new DataSet();
            oracleDataAdapter.Fill(dataSet);
            logBuilder.AppendLine("Data fetch from sourcetable.");
            Console.WriteLine("Data fetch from sourcetable.");
            if (dataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    string insertQuery = "INSERT INTO '" + destinationTableName + "' (EID, NAME,RFID_VALUE,PUNCH_DATETIME,TERMINAL_SL,STATUS) VALUES ('" + dataSet.Tables[0].Rows[i][0] + "','" + dataSet.Tables[0].Rows[i][1] + "','" + dataSet.Tables[0].Rows[i][2] + "','" + dataSet.Tables[0].Rows[i][3] + "','" + dataSet.Tables[0].Rows[i][4] + "','" + dataSet.Tables[0].Rows[i][5] + "')";
                    OracleCommand insertCommand = new OracleCommand(insertQuery, destinationConnection);
                    //  SqlCommand insertCommand = new SqlCommand(insertQuery, destinationConnection);
                    insertCommand.ExecuteNonQuery();
                    Console.WriteLine("Data inserted in '" + destinationTableName + "' for row '" + i + "'.");
                    if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) == 0)
                    {
                        string query1 = "insert into C##ACTA.tempIndexNo(IndexNo) values('" + dataSet.Tables[0].Rows[i][6] + "')";
                        //SqlCommand cmd1 = new OracleCommand(query1, sourceConnection);
                        OracleCommand cmd1 = new OracleCommand(query1, sourceConnection);
                        // SqlCommand cmd1 = new SqlCommand(query1, sourceConnection);
                        cmd1.ExecuteNonQuery();
                        Console.WriteLine("Data inserted in tempIndexNo.");
                    }
                    else
                    {
                        string query1 = "update C##ACTA.tempIndexNo set IndexNo='" + dataSet.Tables[0].Rows[i][6] + "'";
                        OracleCommand cmd1 = new OracleCommand(query1, sourceConnection);
                        // SqlCommand cmd1 = new SqlCommand(query1, sourceConnection);
                        cmd1.ExecuteNonQuery();
                        Console.WriteLine("Data updated in tempIndexNo.");
                    }
                }
            }
        }
        static DataTable getIndexNo(OracleConnection sourceConnection)
        //static DataTable getIndexNo(SqlConnection sourceConnection)
        {
            Console.WriteLine("inside getIndexNo method.");
            logBuilder.AppendLine("inside getIndexNo method.");
            if (sourceConnection.State != ConnectionState.Open)
            {
                sourceConnection.Open();
            }
            string queryString1 = "select isnull(max(IndexNo),0) from C##ACTA.tempIndexNo";
            OracleDataAdapter oracleDataAdapter = new OracleDataAdapter(queryString1, sourceConnection);
            //SqlDataAdapter oracleDataAdapter = new SqlDataAdapter(queryString1, sourceConnection);
            dsmaxId.Clear();
            oracleDataAdapter.Fill(dsmaxId);
            sourceConnection.Close();
            //var id = dsmaxId.Tables[0].Rows[0][0];
            Console.WriteLine("data fetch from tempIndexNo.");
            logBuilder.AppendLine("data fetch from tempIndexNo.");
            return dsmaxId.Tables[0];
        }
        public static void LogInfo(StringBuilder logMessage)
        {
            Console.WriteLine("inside LogInfo method.");
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Logs";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
            {
                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                myFile.Close();
            }
            var fs = System.IO.File.Open(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", FileMode.Append, FileAccess.Write, FileShare.Write);
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.WriteLine(logMessage);
                writer.Close();
            }
        }
    }
}
