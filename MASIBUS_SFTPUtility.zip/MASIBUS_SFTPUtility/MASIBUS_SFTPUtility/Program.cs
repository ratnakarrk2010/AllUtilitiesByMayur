﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
//using System.Data.OracleClient;
using ValidateLicence;
using System.IO;
using System.Net.Mail;
using System.Net;

namespace PanasonicPermanentEmp

{
    class Program
    {
        static StringBuilder logBuilder = new StringBuilder("");
        string connString = ConfigurationManager.AppSettings["connectionstring"];
        static string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log"; // Moved to class level
        static void Main(string[] args) 
        {
            //to check for licence
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
            {
                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                myFile.Close();
            }
            // Before fetching data, check for offline devices
            CheckForOfflineDevices();

            getData();
        }
        //static DataSet dsmaxId = new DataSet();
        static DataTable getData()
        {
            
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            // DateTime date = DateTime.Now.Date; //commented by pratisksha07082023
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]); //add by pratisksha07082023
            DateTime date = DateTime.Today.AddDays(-logDateInDays); //add by pratisksha07082023
            string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
            string table_atteninfo = ConfigurationManager.AppSettings["TABLE_atteninfo"];
            string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
           
            if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += date.ToString(tblDeviceLogsSuffix);
            try
            {
                //Console.WriteLine($"Version: {Environment.Version}");
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string connString = ConfigurationManager.AppSettings["connectionstring"];
                SqlConnection conn1 = new SqlConnection(connectionString);
                SqlConnection conn = new SqlConnection(connString);
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Console.WriteLine("Sql Connection established successfully..!" + conn.ServerVersion);
                logBuilder.Append("Sql Connection established successfully..!" + conn.ServerVersion);    //add logs 
                if (conn1.State != ConnectionState.Open)
                    conn1.Open();


                //string query11 = "select Name from dbo.tempId";
                //SqlDataAdapter adapter11 = new SqlDataAdapter(query11, conn1);
                DataSet dsIndex1 = new DataSet();
                //adapter11.Fill(dsIndex1);
                //if (dsIndex1.Tables[0].Rows.Count > 0)
                //{
                //    string tblname = dsIndex1.Tables[0].Rows[0][0].ToString();
                //    if (tblname != tblDeviceLogs)
                //    {
                //        string query1 = "truncate table tempId";
                //        SqlCommand cmd1 = new SqlCommand(query1, conn1);
                //        cmd1.ExecuteNonQuery();
                //    }
                //}
                //SqlDataAdapter da = new SqlDataAdapter("select count(*) from tempId", conn1);
                //DataSet ds2 = new DataSet("tempId");
                //da.Fill(ds2, "tempId");
                //// Console.WriteLine("data fetch from tempId");

                //if (Convert.ToInt32(ds2.Tables[0].Rows[0][0]) > 0 && Convert.ToInt32(ds2.Tables[0].Rows[0][0]) != 0)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("SQL Connection established successfully..!");
                        logBuilder.Append("SQL Connection established successfully..!");    //add logs 
                        //string queryString1 = "select id from tempId";
                        //SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                        //adapter1.Fill(ds1);
                        // Console.WriteLine("Data fetch from tempId");
                        //string queryString = "select distinct emp.EmployeeCode,'' as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,d.DeviceId as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 )as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join " + tblDeviceLogs + " d on(emp.EmployeeCodeInDevice= d.UserId) where d.DeviceLogId >'" + ds1.Tables[0].Rows[0][0] + "' order by d.DeviceLogId";

                        string queryString = "select distinct emp.EmployeeCode,'' as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,d.DeviceId as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 )as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join DeviceLogs_1_2023 d on(emp.EmployeeCodeInDevice= d.UserId) where d.DeviceId IS NOT NULL and LogDate>= '20230101' and LogDate<= '20230131' order by ENTRYDATE";




                        // Console.WriteLine("Data fetch from" + tblDeviceLogs);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            Console.WriteLine("dsTableCount==>" + ds.Tables[0].Rows.Count);
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                Console.WriteLine("tempdb==>" + i);
                                //string queryString3 = "select count(*)  from atteninfo";
                                string queryString3 = "select count(*)  from " + table_atteninfo;
                                SqlDataAdapter da3 = new SqlDataAdapter(queryString3, conn);
                                DataSet dsSql1 = new DataSet();
                                da3.Fill(dsSql1);


                                int AutoId = Convert.ToInt32(dsSql1.Tables[0].Rows[0][0]) + 1;
                                //if (Convert.ToInt32(dsSql.Tables[0].Rows[0][0]) == 0)
                                //{
                                string entrydate = ds.Tables[0].Rows[i][2].ToString();
                                string entrydate1 = ds.Tables[0].Rows[i][7].ToString();
                                string EmpCode = ds.Tables[0].Rows[i][0].ToString();
                                string NewEmpCode = "";
                                if (EmpCode.Length <= 5)
                                {
                                    if (EmpCode.Length == 5)
                                    {
                                        NewEmpCode = 'A' + EmpCode;
                                    }
                                    if (EmpCode.Length == 4)
                                    {
                                        NewEmpCode = 'A' + "0" + EmpCode;
                                    }
                                    if (EmpCode.Length == 3)
                                    {
                                        NewEmpCode = 'A' + "00" + EmpCode;
                                    }
                                    if (EmpCode.Length == 2)
                                    {
                                        NewEmpCode = 'A' + "000" + EmpCode;
                                    }
                                    if (EmpCode.Length == 1)
                                    {
                                        NewEmpCode = 'A' + "0000" + EmpCode;
                                    }
                                }
                                else
                                {
                                    NewEmpCode = EmpCode;
                                }


                                //string query = "insert into atteninfo(EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',to_date('" + entrydate1 + "', 'dd-mm-yyyy hh24:mi:ss'),'" + ds.Tables[0].Rows[i][8] + "')";
                                string query = "insert into " + table_atteninfo + " (EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',convert(datetime, '" + entrydate + "', 105),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',convert(datetime, '" + entrydate1 + "', 105),'" + ds.Tables[0].Rows[i][8] + "')";

                                SqlCommand cmd = new SqlCommand(query, conn);
                                cmd.ExecuteNonQuery();
                                //Console.WriteLine("Data inserted in atteninfo for row " + i);

                                //string query1 = "update tempId set Id='" + ds.Tables[0].Rows[i][9] + "',Name='" + tblDeviceLogs + "' ";
                                //SqlCommand cmd1 = new SqlCommand(query1, connection);
                                //cmd1.ExecuteNonQuery();

                                //  Console.WriteLine("Data updated in tempId for row" + i);
                                //}
                            }
                            Console.WriteLine("data updated successfully into atteninfo..!");
                            logBuilder.Append("data updated successfully into atteninfo..!");

                        }
                    }
                }
            }
            //    else
            //    {


            //        //using (SqlConnection connection = new SqlConnection(connectionString)
            //        using (SqlConnection sqlConnection = new SqlConnection(connectionString))

            //        {
            //            connection.Open();// open the database connection  
            //            Console.WriteLine("SQL Connection established successfully for first time..!");
            //            logBuilder.Append("SQL Connection established successfully for first time..!");


            //            //string queryString = "select distinct emp.EmployeeCode,'' as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,d.DeviceId as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 ) as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join " + tblDeviceLogs + " d on(emp.EmployeeCodeInDevice= d.UserId) order by d.DeviceLogId";

            //            string queryString = "select distinct emp.EmployeeCode,'' as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,d.DeviceId as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 )as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join DeviceLogs_1_2023 d on(emp.EmployeeCodeInDevice= d.UserId) where d.DeviceId IS NOT NULL and LogDate>= '20230101' and LogDate<= '20230131' order by ENTRYDATE";




            //            SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
            //            adapter.SelectCommand.CommandTimeout = 180;  // seconds
            //            ds = new DataSet();
            //            DataSet dsIndex = new DataSet();
            //            adapter.Fill(ds);
            //            Console.WriteLine("Data fetch from" + tblDeviceLogs);
            //            if (ds.Tables[0].Rows.Count > 0)
            //            {
            //                Console.WriteLine("dsTableCount1==>" + ds.Tables[0].Rows.Count);
            //                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            //                {
            //                    Console.WriteLine("withouttempDb==>" + i);
            //                    //string queryString3 = "select count(*)  from atteninfo";
            //                    string queryString3 = "select count(*)  from " + table_atteninfo;
            //                    SqlDataAdapter da3 = new SqlDataAdapter(queryString3, conn);
            //                    DataSet dsSql1 = new DataSet();
            //                    da3.Fill(dsSql1);
            //                    int AutoId = Convert.ToInt32(dsSql1.Tables[0].Rows[0][0]) + 1;
            //                    //if (Convert.ToInt32(dsSql.Tables[0].Rows[0][0]) == 0)
            //                    //{
            //                    //  Console.WriteLine("inside else of insert method for row" + i);
            //                    string entrydate = ds.Tables[0].Rows[i][2].ToString();
            //                    string entrydate1 = ds.Tables[0].Rows[i][7].ToString();
            //                    string EmpCode = ds.Tables[0].Rows[i][0].ToString();
            //                    string NewEmpCode = "";
            //                    if (EmpCode.Length <= 5)
            //                    {
            //                        if (EmpCode.Length == 5)
            //                        {
            //                            NewEmpCode = 'A' + EmpCode;
            //                        }
            //                        if (EmpCode.Length == 4)
            //                        {
            //                            NewEmpCode = 'A' + "0" + EmpCode;
            //                        }
            //                        if (EmpCode.Length == 3)
            //                        {
            //                            NewEmpCode = 'A' + "00" + EmpCode;
            //                        }
            //                        if (EmpCode.Length == 2)
            //                        {
            //                            NewEmpCode = 'A' + "000" + EmpCode;
            //                        }
            //                        if (EmpCode.Length == 1)
            //                        {
            //                            NewEmpCode = 'A' + "0000" + EmpCode;
            //                        }
            //                    }
            //                    else
            //                    {
            //                        NewEmpCode = EmpCode;
            //                    }

            //                    //string query = "insert into atteninfo(EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',to_date('" + entrydate1 + "', 'dd-mm-yyyy hh24:mi:ss'),'" + ds.Tables[0].Rows[i][8] + "')";
            //                    string query = "insert into " + table_atteninfo + " (EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',convert(datetime, '" + entrydate + "', 105),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',convert(datetime, '" + entrydate1 + "', 105),'" + ds.Tables[0].Rows[i][8] + "')";
            //                    SqlCommand cmd = new SqlCommand(query, conn);
            //                    cmd.ExecuteNonQuery();
            //                    //  Console.WriteLine("Data inserted in atteninfo for row" + i);
            //                    //getMaxId();

            //                    //if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) == 0)
            //                    //{
            //                    //    string query1 = "insert into tempId values('" + ds.Tables[0].Rows[i][9] + "','" + tblDeviceLogs + "')";
            //                    //    SqlCommand cmd1 = new SqlCommand(query1, connection);
            //                    //    cmd1.ExecuteNonQuery();
            //                    //    // Console.WriteLine("Data inserted in tempId for row" + i);
            //                    //}
            //                    //else
            //                    //{
            //                    //    string query1 = "update  tempId set Id='" + ds.Tables[0].Rows[i][9] + "' ,Name='" + tblDeviceLogs + "'";
            //                    //    SqlCommand cmd1 = new SqlCommand(query1, connection);
            //                    //    cmd1.ExecuteNonQuery();
            //                    //    // Console.WriteLine("Data updated in tempId for row" + i);
            //                    //}
            //                    //}
            //                }
            //                Console.WriteLine("data inserted successfully into atteninfo..!");
            //                logBuilder.Append("data inserted successfully into atteninfo..!");
            //                // After fetching data, check for offline devices
            //                CheckForOfflineDevices();
            //            }
            //        }
            //    }

            //}
            catch (Exception ex)
            {
                logBuilder.AppendLine("Inside the catch of atteninfo. " + DateTime.Now);
                logBuilder.AppendLine(ex + "" + DateTime.Now);
                logBuilder.AppendLine("-------------------------------------------END-------------------------------------------\n");
                File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", logBuilder.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {

                logBuilder.AppendLine("failed");
            }
            return ds.Tables[0];
        }
        //static DataTable getMaxId()
        //{
        //    string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        string queryString1 = "select isnull(max(Id),0) from tempId";
        //        SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
        //        dsmaxId.Clear();
        //        adapter1.Fill(dsmaxId);
        //        var id = dsmaxId.Tables[0].Rows[0][0];
        //        return dsmaxId.Tables[0];
        //    }
        //}
        static void CheckForOfflineDevices()
        {
            try
            {
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT DeviceId, DeviceFName, DeviceLocation, LastPing FROM Devices";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DateTime lastPing = Convert.ToDateTime(reader["LastPing"]);
                                TimeSpan timeDifference = DateTime.Now - lastPing;
                                int offlineThresholdInHours = Convert.ToInt32(ConfigurationManager.AppSettings["OFFLINE_THRESHOLD_Hours"]);

                                if (timeDifference.TotalMinutes > offlineThresholdInHours)
                                {
                                    string emailAddress = reader["Email"].ToString();
                                    if (!string.IsNullOrEmpty(emailAddress))
                                    {
                                        SendOfflineDeviceEmail(emailAddress, reader["DeviceFName"].ToString(), reader["DeviceId"].ToString(), reader["DeviceLocation"].ToString(), lastPing);
                                    }
                                    else
                                    {
                                        logBuilder.AppendLine($"Email address not found for offline device: {reader["DeviceFName"].ToString()} ({reader["DeviceId"].ToString()})");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logBuilder.AppendLine("Error while checking for offline devices: " + ex.Message);
            }
        }

        static void SendOfflineDeviceEmail(string emailAddress, string deviceName, string deviceId, string deviceLocation, DateTime lastPing)
        {
            try
            {
                string emailSubject = $"Alert: Device Offline - {deviceName}";
                string emailBody = $"Device {deviceName} ({deviceId}) located at {deviceLocation} is currently offline. Last ping received at: {lastPing}";

                using (MailMessage message = new MailMessage())
                {
                    message.From = new MailAddress(ConfigurationManager.AppSettings["SENDER_EMAIL"]);
                    message.To.Add(emailAddress);
                    message.Subject = emailSubject;
                    message.Body = emailBody;

                    using (SmtpClient smtp = new SmtpClient())
                    {
                        smtp.Host = ConfigurationManager.AppSettings["SMTP_HOST"];
                        smtp.Port = Convert.ToInt32(ConfigurationManager.AppSettings["SMTP_PORT"]);
                        smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["SMTP_ENABLE_SSL"]);
                        smtp.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["SMTP_USERNAME"], ConfigurationManager.AppSettings["SMTP_PASSWORD"]);

                        smtp.Send(message);
                    }

                    logBuilder.AppendLine($"Email sent for offline device: {deviceName} ({deviceId}) to location: {deviceLocation}");
                }
            }
            catch (Exception ex)
            {
                logBuilder.AppendLine($"Error while sending email for offline device {deviceName} ({deviceId}) to location: {deviceLocation}: {ex.Message}");
            }
        }



    }
}

