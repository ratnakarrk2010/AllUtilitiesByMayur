﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using ValidateLicence;
using System.IO;
namespace OracleDataTransferUtility
{
    class Program
    {
        static StringBuilder logBuilder = new StringBuilder("");
        string connString = ConfigurationManager.AppSettings["connectionstring"];
        static void Main(string[] args)
        {
            //to check for licence
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            getData();
        }
        static DataSet dsmaxId = new DataSet();
        static DataTable getData()
        {
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DateTime date = DateTime.Now.Date;
            //DateTime date = Convert.ToDateTime("10/09/2022 12:00:00");
            string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
            string table_atteninfo = ConfigurationManager.AppSettings["TABLE_atteninfo"];
            string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
           
            if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += date.ToString(tblDeviceLogsSuffix);
            try
            {
                //Console.WriteLine($"Version: {Environment.Version}");
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string connString = ConfigurationManager.AppSettings["connectionstring"];
                SqlConnection conn1 = new SqlConnection(connectionString);
                SqlConnection conn = new SqlConnection(connString);
               // OracleConnection conn = new OracleConnection(connString);
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Console.WriteLine("SQL Connection with Server established successfully..!" + conn.ServerVersion);
                if (conn1.State != ConnectionState.Open)
                    conn1.Open();


                string query11 = "select Name from tempId";
                SqlDataAdapter adapter11 = new SqlDataAdapter(query11, conn1);
                DataSet dsIndex1 = new DataSet();
                adapter11.Fill(dsIndex1);
                if (dsIndex1.Tables[0].Rows.Count>0)
                {
                    string tblname = dsIndex1.Tables[0].Rows[0][0].ToString();
                    if (tblname != tblDeviceLogs)
                    {
                        string query1 = "truncate table tempId";
                        SqlCommand cmd1 = new SqlCommand(query1, conn1);
                        cmd1.ExecuteNonQuery();
                    }
                }
                SqlDataAdapter da = new SqlDataAdapter("select count(*) from tempId", conn1);
                DataSet ds2 = new DataSet("tempId");
                da.Fill(ds2, "tempId");
               // Console.WriteLine("data fetch from tempId");

                if (Convert.ToInt32(ds2.Tables[0].Rows[0][0]) > 0 && Convert.ToInt32(ds2.Tables[0].Rows[0][0]) != 0)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("Locally SQL Connection established successfully..!");
                        string queryString1 = "select id from tempId";
                        SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                        adapter1.Fill(ds1);

                        //string queryString = "select distinct emp.EmployeeCode,0 as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,'' as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 )as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join " + tblDeviceLogs + " d on(emp.EmployeeCodeInDevice= d.UserId) where d.DeviceLogId >'" + ds1.Tables[0].Rows[0][0] + "' order by d.DeviceLogId";

                        //string queryString = @"
                        //                    SELECT DISTINCT 
                        //                        emp.EmployeeCode,
                        //                        0 AS TICKETNO,
                        //                        CONVERT(VARCHAR, d.LogDate, 105) AS ENTRYDATE,
                        //                        'Z' AS INOUTFLAG,
                        //                        0 AS TRFFLAG,
                        //                        '' AS UPDATEUID,
                        //                        '' AS LOCATION,
                        //                        CONVERT(VARCHAR, d.LogDate, 105) + ' ' + CONVERT(VARCHAR(5), d.LogDate, 108) AS ENTRYTIME,
                        //                        '' AS ERRMSG,
                        //                        d.DeviceLogId 
                        //                    FROM [dbo].[Employees] emp 
                        //                    JOIN DeviceLogs_1_2025 d 
                        //                        ON (emp.EmployeeCodeInDevice = d.UserId) 
                        //                    ORDER BY d.DeviceLogId";

                        //string queryString = @"
                        //                     SELECT DISTINCT 
                        //                    emp.EmployeeCode,
                        //                    0 AS TICKETNO,
                        //                    CONVERT(VARCHAR, d.LogDate, 105) AS ENTRYDATE,
                        //                    'Z' AS INOUTFLAG,
                        //                    0 AS TRFFLAG,
                        //                    '' AS UPDATEUID,
                        //                    '' AS LOCATION,
                        //                    CONVERT(VARCHAR, d.LogDate, 105) + ' ' + CONVERT(VARCHAR(5), d.LogDate, 108) AS ENTRYTIME,
                        //                    '' AS ERRMSG,
                        //                    d.DeviceLogId 
                        //                FROM [dbo].[Employees] emp 
                        //                JOIN DeviceLogs_3_2025 d 
                        //                    ON emp.EmployeeCodeInDevice = d.UserId 
                        //                WHERE 

                        //                     d.LogDate >= '2025-03-04' 
                        //                ORDER BY d.DeviceLogId;
                        //                ";

                        string queryString = @"SELECT DISTINCT
                                                        emp.EmployeeCode,
                                                        0 AS TICKETNO,
                                                        CONVERT(VARCHAR, d.LogDate, 105) AS ENTRYDATE,
                                                        'Z' AS INOUTFLAG,
                                                        0 AS TRFFLAG,
                                                        '' AS UPDATEUID,
                                                        '' AS LOCATION,
                                                        CONVERT(VARCHAR, d.LogDate, 105) +' ' + CONVERT(VARCHAR(5), d.LogDate, 108) AS                              ENTRYTIME,
                                                        '' AS ERRMSG,
                                                        d.DeviceLogId
                                                    FROM[dbo].[Employees] emp
                                                    JOIN DeviceLogs_6_2026 d
                                                        ON emp.EmployeeCodeInDevice = d.UserId
                                                    WHERE
                                                        d.DeviceLogId > 23090
                                                        AND d.LogDate >= '2026-06-30 00:00:00'
                                                        AND d.LogDate < '2026-07-01 00:00:00'
                                                    ORDER BY d.DeviceLogId;";


                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    
                        adapter.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {                               
                                string queryString3 = "select MAX(srno)  from " + table_atteninfo;
                                
                                SqlDataAdapter da3 = new SqlDataAdapter(queryString3, conn);
                                DataSet dsOracle1 = new DataSet();
                                da3.Fill(dsOracle1);

                                int srno = Convert.ToInt32(dsOracle1.Tables[0].Rows[0][0]) + 1;

                                string entrydate = ds.Tables[0].Rows[i][2].ToString();
                                string entrydate1 = ds.Tables[0].Rows[i][7].ToString();
                                string EmpCode = ds.Tables[0].Rows[i][0].ToString();
                                

                                DateTime d = Convert.ToDateTime(ds.Tables[0].Rows[i][2]);
                                string dd = d.ToString("yyyy-MM-dd");

                                DateTime d1 = Convert.ToDateTime(ds.Tables[0].Rows[i][7]);
                                string dd1 = d1.ToString("yyyy-MM-dd HH:mm:ss");

                             string query = "insert into " + table_atteninfo + "(srno,EmpCode,TicketNo,EntryDate,InOutFlag,EntryTime,TrfFlag,UpdateUID,Location) values('" + srno + "','" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + dd + "','" + ds.Tables[0].Rows[i][3] + "','" + dd1 + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "')";
                                
                                SqlCommand cmd = new SqlCommand(query, conn);
                                cmd.ExecuteNonQuery();
   
                                string query1 = "update tempId set id='" + ds.Tables[0].Rows[i][9] + "',Name='"+tblDeviceLogs+"' ";
                               
                                SqlCommand cmd1 = new SqlCommand(query1, connection);
                                cmd1.ExecuteNonQuery();

                              
                            }
                            Console.WriteLine("data updated successfully to atteninfo..!");
                        }
                    }
                }
                else
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("SQL Connection established successfully for first time..!");

                        //string queryString = "select distinct emp.EmployeeCode,0 as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,'' as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 )as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join " + tblDeviceLogs + " d on(emp.EmployeeCodeInDevice= d.UserId) order by d.DeviceLogId";

                        //string queryString = @"
                        //                    SELECT DISTINCT 
                        //                        emp.EmployeeCode,
                        //                        0 AS TICKETNO,
                        //                        CONVERT(VARCHAR, d.LogDate, 105) AS ENTRYDATE,
                        //                        'Z' AS INOUTFLAG,
                        //                        0 AS TRFFLAG,
                        //                        '' AS UPDATEUID,
                        //                        '' AS LOCATION,
                        //                        CONVERT(VARCHAR, d.LogDate, 105) + ' ' + CONVERT(VARCHAR(5), d.LogDate, 108) AS ENTRYTIME,
                        //                        '' AS ERRMSG,
                        //                        d.DeviceLogId 
                        //                    FROM [dbo].[Employees] emp 
                        //                    JOIN DeviceLogs_1_2025 d 
                        //                        ON (emp.EmployeeCodeInDevice = d.UserId) 
                        //                    ORDER BY d.DeviceLogId";

                        //string queryString = @"
                        //                     SELECT DISTINCT 
                        //                    emp.EmployeeCode,
                        //                    0 AS TICKETNO,
                        //                    CONVERT(VARCHAR, d.LogDate, 105) AS ENTRYDATE,
                        //                    'Z' AS INOUTFLAG,
                        //                    0 AS TRFFLAG,
                        //                    '' AS UPDATEUID,
                        //                    '' AS LOCATION,
                        //                    CONVERT(VARCHAR, d.LogDate, 105) + ' ' + CONVERT(VARCHAR(5), d.LogDate, 108) AS ENTRYTIME,
                        //                    '' AS ERRMSG,
                        //                    d.DeviceLogId 
                        //                FROM [dbo].[Employees] emp 
                        //                JOIN DeviceLogs_3_2025 d 
                        //                    ON emp.EmployeeCodeInDevice = d.UserId 
                        //                WHERE 

                        //                     d.LogDate >= '2025-03-04' 
                        //                ORDER BY d.DeviceLogId;
                        //                ";

                        string queryString = @"SELECT DISTINCT
                                                        emp.EmployeeCode,
                                                        0 AS TICKETNO,
                                                        CONVERT(VARCHAR, d.LogDate, 105) AS ENTRYDATE,
                                                        'Z' AS INOUTFLAG,
                                                        0 AS TRFFLAG,
                                                        '' AS UPDATEUID,
                                                        '' AS LOCATION,
                                                        CONVERT(VARCHAR, d.LogDate, 105) +' ' + CONVERT(VARCHAR(5), d.LogDate, 108) AS                              ENTRYTIME,
                                                        '' AS ERRMSG,
                                                        d.DeviceLogId
                                                    FROM[dbo].[Employees] emp
                                                    JOIN DeviceLogs_6_2026 d
                                                        ON emp.EmployeeCodeInDevice = d.UserId
                                                    WHERE
                                                        d.DeviceLogId > 23090
                                                        AND d.LogDate >= '2026-06-30 00:00:00'
                                                        AND d.LogDate < '2026-07-01 00:00:00'
                                                    ORDER BY d.DeviceLogId;";


                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                        adapter.SelectCommand.CommandTimeout = 180;  // seconds
                        ds = new DataSet();
                        DataSet dsIndex = new DataSet();
                        adapter.Fill(ds);
                        Console.WriteLine("Data fetch from"+ tblDeviceLogs);
                        if (ds.Tables[0].Rows.Count > 0)
                        {

                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string queryString3 = "select MAX(srno)  from " + table_atteninfo;
                                
                                SqlDataAdapter da3 = new SqlDataAdapter(queryString3, conn);
                                DataSet dsOracle1 = new DataSet();
                                da3.Fill(dsOracle1);
                                int srno = Convert.ToInt32(dsOracle1.Tables[0].Rows[0][0]) + 1;
                                //int srno = 504120;
                                string entrydate = ds.Tables[0].Rows[i][2].ToString();
                                string entrydate1 = ds.Tables[0].Rows[i][7].ToString();
                                string EmpCode = ds.Tables[0].Rows[i][0].ToString();
                                //string NewEmpCode = "";
                               

                                DateTime d = Convert.ToDateTime(ds.Tables[0].Rows[i][2]);
                                string dd = d.ToString("yyyy-MM-dd");

                                DateTime d1 = Convert.ToDateTime(ds.Tables[0].Rows[i][7]);
                                string dd1 = d1.ToString("yyyy-MM-dd HH:mm:ss");
                                string query = "insert into " + table_atteninfo + "(srno,EmpCode,TicketNo,EntryDate,InOutFlag,EntryTime,TrfFlag,UpdateUID,Location) values('" + srno + "','" + ds.Tables[0].Rows[i][0] + "','" + ds.Tables[0].Rows[i][1] + "','" + dd + "','" + ds.Tables[0].Rows[i][3] + "','" + dd1 + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "')";

                                SqlCommand cmd = new SqlCommand(query, conn);
                                cmd.ExecuteNonQuery();
                              //  Console.WriteLine("Data inserted in atteninfo for row" + i);
                                getMaxId();

                                    if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) == 0)
                                    {
                                  
                                    string query1 = "insert into tempId values('" + ds.Tables[0].Rows[i][9] + "','" + tblDeviceLogs + "')";
                                    SqlCommand cmd1 = new SqlCommand(query1, connection);
                                        cmd1.ExecuteNonQuery();
                                       // Console.WriteLine("Data inserted in tempId for row" + i);
                                    }
                                    else
                                    {
                                        string query1 = "update  tempId set Id='" + ds.Tables[0].Rows[i][9] + "',Name='" + tblDeviceLogs + "'";
                                        SqlCommand cmd1 = new SqlCommand(query1, connection);
                                        cmd1.ExecuteNonQuery();
                                       // Console.WriteLine("Data updated in tempId for row" + i);
                                    }
                                
                            }
                            Console.WriteLine("data inserted successfully into atteninfo..!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {

                logBuilder.AppendLine("failed");
            }
            return ds.Tables[0];
        }
        static DataTable getMaxId()
        {
            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string queryString1 = "select isnull(max(Id),0) from tempId";
                SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                dsmaxId.Clear();
                adapter1.Fill(dsmaxId);
                var id = dsmaxId.Tables[0].Rows[0][0];
                return dsmaxId.Tables[0];
            }
        }
    }
}
