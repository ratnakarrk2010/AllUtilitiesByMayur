﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ValidateLicence;
using System.Net;
using System.Net.Sockets;
using System.Security.Principal;

namespace SFTPUtility
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string licenceEndDate = ConfigurationManager.AppSettings["LICENCE"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + "Logs\\";
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(licenceEndDate));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }

            StringBuilder logs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            string timeEntryFormat = ConfigurationManager.AppSettings["TIME_ENTRY_DATE_FORMAT"];
            string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            string NetworkFolderPath = ConfigurationManager.AppSettings["NETWORK_FOLDER"];
            string filenamePrefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }

            try
            {
                List<FileDataModel> FetchedData = new List<FileDataModel>();
                DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);
                DataTable tblDeviceLogs = getData(logs, logDateToFetch);


                #region For .dat File
                var serverPath = AppDomain.CurrentDomain.BaseDirectory;
                string datfilename = logDateToFetch.ToString("dd-MM-yyyy") + ".dat";
                 string dir = serverPath + "Employee Punch Data\\";
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                
                //string datpath = serverPath + "Employee Punch Data\\" + datfilename;
                //var myFile = System.IO.File.Create(datpath);
                //myFile.Close();
                string datpath = localFolderPath + datfilename;
                string datpath1 = NetworkFolderPath + datfilename;
                #endregion





                string datmessage = "";

                foreach (DataRow row in tblDeviceLogs.Rows)
                {
                    FileDataModel dataModel = new FileDataModel();
                    dataModel.UserId = row.ItemArray[0].ToString();
                    dataModel.LogDate = Convert.ToDateTime(row.ItemArray[1]);
                    dataModel.DeviceId = Convert.ToString(row.ItemArray[2]);
                    FetchedData.Add(dataModel);
                }

                var employeeDataGroup = FetchedData.GroupBy(x => x.UserId).ToList();

                foreach (var empGroup in employeeDataGroup)
                {
                     var firstIn = empGroup.OrderBy(x => x.LogDate).FirstOrDefault();
                     var lastOut = empGroup.OrderByDescending(x => x.LogDate).FirstOrDefault();

                    var IN = "";
                    string NewEmpCode = "";
                    string EmpCode = empGroup.Key;
                    if (EmpCode.Length <= 8)
                    {
                        if (EmpCode.Length == 8)
                        {
                            NewEmpCode = "0" + EmpCode;
                        }
                        if (EmpCode.Length == 7)
                        {
                            NewEmpCode =  "00" + EmpCode;
                        }
                        if (EmpCode.Length == 6)
                        {
                            NewEmpCode = "000" + EmpCode;
                        }
                        if (EmpCode.Length == 5)
                        {
                            NewEmpCode = "0000" + EmpCode;
                        }
                        if (EmpCode.Length == 4)
                        {
                            NewEmpCode = "00000" + EmpCode;
                        }
                        if (EmpCode.Length == 3)
                        {
                            NewEmpCode = "000000" + EmpCode;
                        }
                        if (EmpCode.Length == 2)
                        {
                            NewEmpCode =  "0000000" + EmpCode;
                        }
                        if (EmpCode.Length == 1)
                        {
                            NewEmpCode =  "0000000" + EmpCode;
                        }
                    }
                    else
                    {
                        NewEmpCode = EmpCode;
                    }
                    datmessage += String.Format("{0}", NewEmpCode);
                    datmessage += String.Format("{0}", "\t");
                    datmessage += String.Format("{0}", firstIn.LogDate.ToString("dd-MMM-yyyy"));
                    datmessage += String.Format("{0}", IN.PadRight(1));
                     
                    datmessage += String.Format("{0}", firstIn.LogDate.ToString("HH:mm:ss"));
                    datmessage += String.Format("{0}", "\t");
                    datmessage += String.Format("{0}", firstIn.DeviceId);
                    datmessage += String.Format("{0}", "\t");
                    datmessage += String.Format("{0}", "0");
                    datmessage += Environment.NewLine;
                    datmessage += String.Format("{0}", NewEmpCode);
                    datmessage += String.Format("{0}", "\t");
                    datmessage += String.Format("{0}", lastOut.LogDate.ToString("dd-MMM-yyyy"));
                    datmessage += String.Format("{0}", IN.PadRight(1));
                    datmessage += String.Format("{0}", lastOut.LogDate.ToString("HH:mm:ss"));
                    datmessage += String.Format("{0}", "\t");
                    datmessage += String.Format("{0}", lastOut.DeviceId);
                    datmessage += String.Format("{0}", "\t");
                    datmessage += String.Format("{0}", "0");
                    datmessage += Environment.NewLine;
                }
                
                if (File.Exists(datpath))
                {
                    File.Delete(datpath);
                }
                if (File.Exists(datpath1))
                {
                    File.Delete(datpath1);
                }

                var datfs = System.IO.File.Open(datpath, FileMode.Append, FileAccess.Write, FileShare.Write);
                using (StreamWriter writer = new StreamWriter(datfs))
                {
                    writer.WriteLine(datmessage);
                    writer.Close();
                }

                datfs = System.IO.File.Open(datpath1, FileMode.Append, FileAccess.Write, FileShare.Write);
                using (StreamWriter writer = new StreamWriter(datfs))
                {
                    writer.WriteLine(datmessage);
                    writer.Close();
                }


                //  File.WriteAllText(localFolderPath + @"\" + datfilename, fileContents.ToString());
                logs.AppendLine("Locally file '" + datfilename + "' created successfully");
                //File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
                Console.WriteLine("Locally file '" + datfilename + "' created successfully");



                #region

               


               
                //File.Copy(datpath, ftpDestinationFolder + datfilename, true);

                
                #endregion

             //   uploadFilesToFTP(datpath, datmessage.ToString(), logs);

                logs.AppendLine("File '" + datfilename + "' created successfully on newwork machine");
              //  File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
                Console.WriteLine("File '" + datfilename + "' created successfully on newwork machine");
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".dat", logs.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".dat", logs.ToString());
            }
        }

        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + "Logs\\";
            try
            {
                string tblDevice = ConfigurationManager.AppSettings["TABLE_DEVICE"];
                string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
                string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string logDateTime = ConfigurationManager.AppSettings["LOG_DATE_TIME"];
                string logDateTimeCondition = ConfigurationManager.AppSettings["LOG_DATE_TIME_CONDITION"];
                string direction_in = ConfigurationManager.AppSettings["DIRECTION_IN"];
                string direction_out = ConfigurationManager.AppSettings["DIRECTION_OUT"];
                string direction_altInOut = ConfigurationManager.AppSettings["DIRECTION_ALT_IN_OUT"];
                string BranchIdList = ConfigurationManager.AppSettings["BranchId"];
                string[] BranchList = BranchIdList.Split(',');
                if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach(var branchid in BranchList)
                    {
                        DataSet ds = new DataSet();
                        string queryString = "select ATDTrn.UserID as UserId, Edatetime as LogDate, 1 as DeviceId from Mx_ATDEventTrn ATDTrn join Mx_UserMst UsrMst on(ATDTrn.UserID = UsrMst.UserID) join Mx_BranchMst BrnchMst on(UsrMst.BRCID = BrnchMst.BRCID) where Edatetime >= '" + logDateToFetch.ToString("yyyy-MM-dd") + "' and Edatetime < '" + logDateToFetch.AddDays(1).ToString("yyyy-MM-dd") + "' and BrnchMst.BRCID = " + branchid +" ";

                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);

                        adapter.Fill(ds, "tblDeviceLogs");
                        deviceLogs.Merge(ds);
                    }
                    connection.Close();
                }

            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".dat", logs.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            
            return deviceLogs.Tables[0];
        }

        static void uploadFilesToFTP(string fileName, string fileContents, StringBuilder logs)
        {
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + "Logs\\";
            string host = ConfigurationManager.AppSettings["HOST"];
            if (string.IsNullOrEmpty(host) == false)
            {
                string username = ConfigurationManager.AppSettings["USERNAME"];
                string password = ConfigurationManager.AppSettings["PASSWORD"];
                string ftpDestinationFolder = ConfigurationManager.AppSettings["FTP_DESTINATION_FOLDER"];

                string ftpFilePath = "ftp://" + host  + "/" + fileName;

               // string ftpFilePath = "ftp://" + host + ftpDestinationFolder + "/" + fileName;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpFilePath);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential(username, password);

                byte[] bytesFileContents = Encoding.Default.GetBytes(fileContents);
                request.ContentLength = fileContents.Length;

                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(bytesFileContents, 0, bytesFileContents.Length);
                }

                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                {
                    logs.AppendLine("Uploaded file '" + fileName + "' successfully");
                    File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
                    Console.WriteLine("Uploaded file '" + fileName + "' successfully");
                }
            }
            else
            {
                logs.AppendLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
                Console.WriteLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
            }
        }
    }

    public class FileDataModel
    {
        public string UserId { get; set; }
        public DateTime LogDate { get; set; }
        public string DeviceId { get; set; }
    }
}
