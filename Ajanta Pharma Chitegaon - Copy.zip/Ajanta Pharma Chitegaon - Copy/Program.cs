﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using ValidateLicence;
using System.IO;
using System.Globalization;

namespace OracleDataTransferUtility
{
    class Program
    {
        static StringBuilder sb = new StringBuilder("");
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            getData();
        }
        static DataSet dsmaxId = new DataSet();
        static DataTable getData()
        {
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            if (!File.Exists(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))
            {
                var myFile = System.IO.File.Create(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
                myFile.Close();
            }


            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            //DateTime date = DateTime.Now.Date; 
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            DateTime date = DateTime.Today.AddDays(-logDateInDays);
            string table_atteninfo = ConfigurationManager.AppSettings["OracleTable"];
            try
            {
                sb.AppendLine("-----------------------------------" + DateTime.Now + "-----------------------------------");
                string sql_connectionString = ConfigurationManager.AppSettings["SQL_connectionstring"];
                using (SqlConnection connection = new SqlConnection(sql_connectionString))
                {
                    connection.Open();
                    sb.AppendLine("SQL Connection established successfully. " + DateTime.Now);
                    Console.WriteLine("SQL Connection established successfully.");
                    string queryString1 = "select * from temp";
                    SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                    adapter1.Fill(ds1);
                    sb.AppendLine("Data fetched from temp. " + DateTime.Now);
                    DateTime date1 = Convert.ToDateTime(ds1.Tables[0].Rows[0][1]);
                   // string datee= DateTime.ParseExact(date.ToString(), "dd-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None).ToString("dd/MM/yyyy");
                    if (date1 != date)
                    {
                        string query = "update temp set IndexKey='" + 0 + "',Date='"+ date + "'";
                        SqlCommand cmd1 = new SqlCommand(query, connection);
                        cmd1.ExecuteNonQuery();
                    }
                    string queryString = "SELECT top(500) userid as empno,convert(varchar, transactiontime, 103)as swipe_date,FORMAT(transactiontime,'HHmm') as time,IndexKey FROM NGAC_AUTHLOG WHERE IndexKey>'" + ds1.Tables[0].Rows[0][0] + "' AND TransactionTime >= '" + date.ToString("yyyy-MM-dd") + "' and TransactionTime < '" + date.AddDays(1).ToString("yyyy-MM-dd") + "' ORDER BY IndexKey";

                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.Fill(ds);
                    sb.AppendLine("Data fetched from NGAC_AUTHLOG. " + DateTime.Now);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Program objProgram = new Program();
                        DataTable dt = new DataTable();
                        dt.Columns.Add("EmpNo");
                        dt.Columns.Add("Swipe_Date");
                        dt.Columns.Add("Time");
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            string empno = ds.Tables[0].Rows[i][0].ToString();
                            string swipe_date = ds.Tables[0].Rows[i][1].ToString();
                            string time = ds.Tables[0].Rows[i][2].ToString();
                            DataRow dr = dt.NewRow();
                            dr["EmpNo"] = empno;
                            dr["Swipe_Date"] = swipe_date;
                            dr["Time"] = time;
                            dt.Rows.Add(dr);



                            /*  string query = "insert into " + table_atteninfo + "(EmpNo,Swipe_Date,Time) values('" + empno + "',to_date('" + swipe_date + "', 'dd/mm/yyyy'),'" + ds.Tables[0].Rows[i][2] + "')";
                              OracleCommand cmd = new OracleCommand(query, conn);
                              cmd.ExecuteNonQuery();*/


                        }
                        objProgram.SaveUsingOracleBulkCopy(table_atteninfo, dt);
                        sb.AppendLine("Data transfer successfully. " + DateTime.Now);
                        DataTable dt1 = ds.Tables[0];
                        DataRow lastRow = dt1.Rows[dt1.Rows.Count - 1];
                        string query = "update temp set IndexKey='" + lastRow.ItemArray[3] + "'";
                        SqlCommand cmd1 = new SqlCommand(query, connection);
                        cmd1.ExecuteNonQuery();
                        sb.AppendLine("temp updated successfully." + DateTime.Now);

                        sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                        Console.WriteLine("Data transfer successfully.");
                    }
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine("Inside catch of getdata method. " + DateTime.Now);
                sb.AppendLine(ex + "" + DateTime.Now);
                sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", sb.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            return ds.Tables[0];
        }
        public void SaveUsingOracleBulkCopy(string destTableName, DataTable dt)
        {
            try
            {
                string oracle_connectionString = ConfigurationManager.AppSettings["Oracle_connectionstring"];
                using (var connection = new Oracle.DataAccess.Client.OracleConnection(oracle_connectionString))
                {
                    connection.Open();
                    sb.AppendLine("Oracle Connection established successfully. " + DateTime.Now);
                    Console.WriteLine("Oracle Connection established successfully..!" + connection.ServerVersion);
                    using (var bulkCopy = new Oracle.DataAccess.Client.OracleBulkCopy(connection, Oracle.DataAccess.Client.OracleBulkCopyOptions.UseInternalTransaction))
                    {
                        bulkCopy.DestinationTableName = destTableName;
                        bulkCopy.BulkCopyTimeout = 600;
                        bulkCopy.WriteToServer(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
                sb.AppendLine("Inside catch of SaveUsingOracleBulkCopy method. " + DateTime.Now);
                sb.AppendLine(ex + "" + DateTime.Now);
                sb.AppendLine("-------------------------------------------END-------------------------------------------\n");
                File.AppendAllText(logFolder + @"\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", sb.ToString());
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
    }
}

