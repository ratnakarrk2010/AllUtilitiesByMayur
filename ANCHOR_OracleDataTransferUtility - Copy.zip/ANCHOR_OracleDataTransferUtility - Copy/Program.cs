﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using ValidateLicence;
using System.IO;
namespace OracleDataTransferUtility
{
    class Program
    {
        static StringBuilder logBuilder = new StringBuilder("");
        string connString = ConfigurationManager.AppSettings["connectionstring"];
        static void Main(string[] args)
        {
            //to check for licence
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                // Console.WriteLine("Licence expired");
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            getData();
        }
        static DataSet dsmaxId = new DataSet();
        static DataTable getData()
        {
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
             DateTime date = DateTime.Now.Date; //commented by pratisksha07082023
            //int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]); //add by pratisksha07082023
            //DateTime date = DateTime.Today.AddDays(-logDateInDays); //add by pratisksha07082023
            string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
            string table_atteninfo = ConfigurationManager.AppSettings["TABLE_atteninfo"];
            string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
           
            if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += date.ToString(tblDeviceLogsSuffix);
            try
            {
                //Console.WriteLine($"Version: {Environment.Version}");
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string connString = ConfigurationManager.AppSettings["connectionstring"];
                SqlConnection conn1 = new SqlConnection(connectionString);
                OracleConnection conn = new OracleConnection(connString);
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Console.WriteLine("Oracle Connection established successfully..!" + conn.ServerVersion);
                if (conn1.State != ConnectionState.Open)
                    conn1.Open();


                string query11 = "select Name from tempId";
                SqlDataAdapter adapter11 = new SqlDataAdapter(query11, conn1);
                DataSet dsIndex1 = new DataSet();
                adapter11.Fill(dsIndex1);
                if (dsIndex1.Tables[0].Rows.Count>0)
                {
                    string tblname = dsIndex1.Tables[0].Rows[0][0].ToString();
                    if (tblname != tblDeviceLogs)
                    {
                        string query1 = "truncate table tempId";
                        SqlCommand cmd1 = new SqlCommand(query1, conn1);
                        cmd1.ExecuteNonQuery();
                    }
                }
                SqlDataAdapter da = new SqlDataAdapter("select count(*) from tempId", conn1);
                DataSet ds2 = new DataSet("tempId");
                da.Fill(ds2, "tempId");
               // Console.WriteLine("data fetch from tempId");

                if (Convert.ToInt32(ds2.Tables[0].Rows[0][0]) > 0 && Convert.ToInt32(ds2.Tables[0].Rows[0][0]) != 0)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("SQL Connection established successfully..!");
                        string queryString1 = "select id from tempId";
                        SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                        adapter1.Fill(ds1);
                       // Console.WriteLine("Data fetch from tempId");
                        string queryString = "select distinct emp.EmployeeCode,'' as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,d.DeviceId as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 )as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join " + tblDeviceLogs + " d on(emp.EmployeeCodeInDevice= d.UserId) where d.DeviceLogId >'" + ds1.Tables[0].Rows[0][0] + "' order by d.DeviceLogId";

                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    
                        adapter.Fill(ds);
                       // Console.WriteLine("Data fetch from" + tblDeviceLogs);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                //string queryString3 = "select count(*)  from atteninfo";
                                string queryString3 = "select count(*)  from "+ table_atteninfo;
                                OracleDataAdapter da3 = new OracleDataAdapter(queryString3, conn);
                                DataSet dsOracle1 = new DataSet();
                                da3.Fill(dsOracle1);


                                int AutoId = Convert.ToInt32(dsOracle1.Tables[0].Rows[0][0]) + 1;
                                //if (Convert.ToInt32(dsOracle.Tables[0].Rows[0][0]) == 0)
                                //{
                                string entrydate = ds.Tables[0].Rows[i][2].ToString();
                                string entrydate1 = ds.Tables[0].Rows[i][7].ToString();
                                string EmpCode = ds.Tables[0].Rows[i][0].ToString();
                                string NewEmpCode = "";
                                if (EmpCode.Length <= 5)
                                {
                                    if (EmpCode.Length == 5)
                                    {
                                        NewEmpCode = 'A' + EmpCode;
                                    }
                                    if (EmpCode.Length == 4)
                                    {
                                        NewEmpCode = 'A' + "0" + EmpCode;
                                    }
                                    if (EmpCode.Length == 3)
                                    {
                                        NewEmpCode = 'A' + "00" + EmpCode;
                                    }
                                    if (EmpCode.Length == 2)
                                    {
                                        NewEmpCode = 'A' + "000" + EmpCode;
                                    }
                                    if (EmpCode.Length == 1)
                                    {
                                        NewEmpCode = 'A' + "0000" + EmpCode;
                                    }
                                }
                                else
                                {
                                    NewEmpCode = EmpCode;
                                }
								
									
                                //string query = "insert into atteninfo(EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',to_date('" + entrydate1 + "', 'dd-mm-yyyy hh24:mi:ss'),'" + ds.Tables[0].Rows[i][8] + "')";
                                string query = "insert into "+ table_atteninfo + "(EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',to_date('" + entrydate1 + "', 'dd-mm-yyyy hh24:mi:ss'),'" + ds.Tables[0].Rows[i][8] + "')";
                                OracleCommand cmd = new OracleCommand(query, conn);
                                cmd.ExecuteNonQuery();
                                //Console.WriteLine("Data inserted in atteninfo for row " + i);
                                
                                string query1 = "update tempId set Id='" + ds.Tables[0].Rows[i][9] + "',Name='"+tblDeviceLogs+"' ";
                                SqlCommand cmd1 = new SqlCommand(query1, connection);
                                cmd1.ExecuteNonQuery();

                              //  Console.WriteLine("Data updated in tempId for row" + i);
                                //}
                            }
                            Console.WriteLine("data updated successfully into atteninfo..!");
                        }
                    }
                }
                else
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("SQL Connection established successfully for first time..!");

                        
                        string queryString = "select distinct emp.EmployeeCode,'' as TICKETNO,convert(varchar, d.LogDate, 105)as ENTRYDATE,'Z' as INOUTFLAG,0 AS TRFFLAG,'' AS UPDATEUID,d.DeviceId as LOCATION,convert(varchar, d.LogDate, 105)+' '+convert(VARCHAR(5),d.LogDate,108 ) as ENTRYTIME,'' AS ERRMSG,d.DeviceLogId from [dbo].[Employees] emp join " + tblDeviceLogs + " d on(emp.EmployeeCodeInDevice= d.UserId) order by d.DeviceLogId";

                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                        adapter.SelectCommand.CommandTimeout = 180;  // seconds
                        ds = new DataSet();
                        DataSet dsIndex = new DataSet();
                        adapter.Fill(ds);
                        Console.WriteLine("Data fetch from"+ tblDeviceLogs);
                        if (ds.Tables[0].Rows.Count > 0)
                        {

                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {

                                //string queryString3 = "select count(*)  from atteninfo";
                                string queryString3 = "select count(*)  from " + table_atteninfo;
                                OracleDataAdapter da3 = new OracleDataAdapter(queryString3, conn);
                                DataSet dsOracle1 = new DataSet();
                                da3.Fill(dsOracle1);
                                int AutoId = Convert.ToInt32(dsOracle1.Tables[0].Rows[0][0]) + 1;
                                //if (Convert.ToInt32(dsOracle.Tables[0].Rows[0][0]) == 0)
                                //{
                              //  Console.WriteLine("inside else of insert method for row" + i);
                                string entrydate = ds.Tables[0].Rows[i][2].ToString();
                                string entrydate1 = ds.Tables[0].Rows[i][7].ToString();
                                string EmpCode = ds.Tables[0].Rows[i][0].ToString();
                                string NewEmpCode = "";
                                if (EmpCode.Length <= 5)
                                {
                                    if (EmpCode.Length == 5)
                                    {
                                        NewEmpCode = 'A' + EmpCode;
                                    }
                                    if (EmpCode.Length == 4)
                                    {
                                        NewEmpCode = 'A' + "0" + EmpCode;
                                    }
                                    if (EmpCode.Length == 3)
                                    {
                                        NewEmpCode = 'A' + "00" + EmpCode;
                                    }
                                    if (EmpCode.Length == 2)
                                    {
                                        NewEmpCode = 'A' + "000" + EmpCode;
                                    }
                                    if (EmpCode.Length == 1)
                                    {
                                        NewEmpCode = 'A' + "0000" + EmpCode;
                                    }
                                }
                                else
                                {
                                    NewEmpCode = EmpCode;
                                }

                                //string query = "insert into atteninfo(EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',to_date('" + entrydate1 + "', 'dd-mm-yyyy hh24:mi:ss'),'" + ds.Tables[0].Rows[i][8] + "')";
                                string query = "insert into " + table_atteninfo + " (EMPCODE,TICKETNO,ENTRYDATE,INOUTFLAG,TRFFLAG,UPDATEUID,LOCATION,ENTRYTIME,ERRMSG) values('" + NewEmpCode + "','" + ds.Tables[0].Rows[i][1] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "','" + ds.Tables[0].Rows[i][5] + "','" + ds.Tables[0].Rows[i][6] + "',to_date('" + entrydate1 + "', 'dd-mm-yyyy hh24:mi:ss'),'" + ds.Tables[0].Rows[i][8] + "')";
                                OracleCommand cmd = new OracleCommand(query, conn);
                                cmd.ExecuteNonQuery();
                              //  Console.WriteLine("Data inserted in atteninfo for row" + i);
                                getMaxId();

                                    if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) == 0)
                                    {
                                        string query1 = "insert into tempId values('" + ds.Tables[0].Rows[i][9] + "','"+tblDeviceLogs+"')";
                                        SqlCommand cmd1 = new SqlCommand(query1, connection);
                                        cmd1.ExecuteNonQuery();
                                       // Console.WriteLine("Data inserted in tempId for row" + i);
                                    }
                                    else
                                    {
                                        string query1 = "update  tempId set Id='" + ds.Tables[0].Rows[i][9] + "' ,Name='"+tblDeviceLogs+"'";
                                        SqlCommand cmd1 = new SqlCommand(query1, connection);
                                        cmd1.ExecuteNonQuery();
                                       // Console.WriteLine("Data updated in tempId for row" + i);
                                    }
                                //}
                            }
                            Console.WriteLine("data inserted successfully into atteninfo..!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {

                logBuilder.AppendLine("failed");
            }
            return ds.Tables[0];
        }
        static DataTable getMaxId()
        {
            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string queryString1 = "select isnull(max(Id),0) from tempId";
                SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                dsmaxId.Clear();
                adapter1.Fill(dsmaxId);
                var id = dsmaxId.Tables[0].Rows[0][0];
                return dsmaxId.Tables[0];
            }
        }
    }
}
