﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using ValidateLicence;
using System.IO;

namespace SQLToOracleDataTransfer
{
    class Program
    {
        static StringBuilder logBuilder = new StringBuilder("");
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Failed");
                Console.ReadKey();
                return;
            }
            try
            {
                DataSet ds = new DataSet();
                DataSet ds1 = new DataSet();
                DateTime date = DateTime.Now.Date;
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string connString = ConfigurationManager.AppSettings["connectionstring"];
                SqlConnection conn1 = new SqlConnection(connectionString);
                OracleConnection conn = new OracleConnection(connString);
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                Console.WriteLine("Oracle Connection established successfully..!" + conn.ServerVersion);
                if (conn1.State != ConnectionState.Open)
                    conn1.Open();
                SqlDataAdapter da = new SqlDataAdapter("select count(*) from tbl_IndexNo", conn1);
                DataSet ds2 = new DataSet("tempId");
                da.Fill(ds2, "tempId");
                getMaxId();
                // Console.WriteLine("data fetch from tempId");

                if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) > 0 && Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) != 0)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("SQL Connection established successfully..!");
                        string queryString1 = "select DailyTrnId from tempId";
                        SqlDataAdapter adapter1 = new SqlDataAdapter(queryString1, connection);
                        adapter1.Fill(ds1);
                        string queryString = "select othrs,TranDate,Login,LogOut,EmployeeId,Late,DailyTrnId from DailyTransaction where trandate='" + date + "'";
                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                        adapter.Fill(ds);
                        Console.WriteLine("Data fetch from DailyTransaction");
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string entrydate = ds.Tables[0].Rows[i][1].ToString();
                                string query = "insert into PAT_ATTEN_DTL (OT_HRS,ATTEN_DATE,TIME_IN,TIME_OUT,EMP_ID) values('" + ds.Tables[0].Rows[i][0] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][2] + "','" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "')";
                                OracleCommand cmd = new OracleCommand(query, conn);
                                cmd.ExecuteNonQuery();
                                //Console.WriteLine("Data inserted in atteninfo for row " + i);

                                string query1 = "update tbl_IndexNo set DailyTrnId='" + ds.Tables[0].Rows[i][6] + "'";
                                SqlCommand cmd1 = new SqlCommand(query1, connection);
                                cmd1.ExecuteNonQuery();

                                //  Console.WriteLine("Data updated in tempId for row" + i);
                                //}
                            }
                            LogInfo("data inserted successfully into PAT_ATTEN_DTL..!");
                            Console.WriteLine("data inserted successfully into PAT_ATTEN_DTL..!");
                        }
                    }
                }
                else
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// open the database connection  
                        Console.WriteLine("SQL Connection established successfully for first time..!");

                        string queryString = "select othrs,TranDate,Login,LogOut,EmployeeId,Late,DailyTrnId from DailyTransaction where trandate='" + date + "'";
                        SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                        adapter.SelectCommand.CommandTimeout = 180;  // seconds
                        ds = new DataSet();
                        DataSet dsIndex = new DataSet();
                        adapter.Fill(ds);
                        Console.WriteLine("Data fetch from Wetos");
                        if (ds.Tables[0].Rows.Count > 0)
                        {

                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string entrydate = ds.Tables[0].Rows[i][1].ToString();
                                string query = "insert into PAT_ATTEN_DTL (OT_HRS,ATTEN_DATE,TIME_IN,TIME_OUT,EMP_ID) values('" + ds.Tables[0].Rows[i][0] + "',to_date('" + entrydate + "', 'dd-mm-yyyy'),'" + ds.Tables[0].Rows[i][2] + "','" + ds.Tables[0].Rows[i][3] + "','" + ds.Tables[0].Rows[i][4] + "')";
                                OracleCommand cmd = new OracleCommand(query, conn);
                                cmd.ExecuteNonQuery();
                                //  Console.WriteLine("Data inserted in atteninfo for row" + i);
                                getMaxId();

                                if (Convert.ToInt32(dsmaxId.Tables[0].Rows[0][0]) == 0)
                                {
                                    string query1 = "insert into tbl_IndexNo values('" + ds.Tables[0].Rows[i][6] + "')";
                                    SqlCommand cmd1 = new SqlCommand(query1, connection);
                                    cmd1.ExecuteNonQuery();
                                    // Console.WriteLine("Data inserted in tempId for row" + i);
                                }
                                else
                                {
                                    string query1 = "update tbl_IndexNo set DailyTrnId='" + ds.Tables[0].Rows[i][6] + "'";
                                    SqlCommand cmd1 = new SqlCommand(query1, connection);
                                    cmd1.ExecuteNonQuery();
                                    // Console.WriteLine("Data updated in tempId for row" + i);
                                }
                            }
                        }
                        LogInfo("data inserted successfully into PAT_ATTEN_DTL..!");
                        Console.WriteLine("data inserted successfully into PAT_ATTEN_DTL..!");
                        }
                    }
                
            }
            catch (Exception ex)
            {
                LogInfo(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            finally
            {
                LogInfo("failed");
                logBuilder.AppendLine("failed");
            }

        }
        static DataSet dsmaxId = new DataSet();
        static DataTable getMaxId()
        {
            string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query11 = "select isnull(max(DailyTrnId),0) from tbl_IndexNo";
                SqlDataAdapter adapter11 = new SqlDataAdapter(query11, connectionString);
                dsmaxId.Clear();
                adapter11.Fill(dsmaxId);
                var id = dsmaxId.Tables[0].Rows[0][0];
                return dsmaxId.Tables[0];
            }
        }
        public static void LogInfo(string logMessage)
        {
            var serverPath = AppDomain.CurrentDomain.BaseDirectory;
            var log = serverPath + "\\" + "LogFile";
            if (System.IO.Directory.Exists(log))
            {
                System.IO.Directory.CreateDirectory(log);
            }
            string path = log + "\\Logs" + DateTime.Today.ToString("ddMMyyyy") + ".txt";

            if (!File.Exists(path))
            {
                var myFile = File.Create(path);
                myFile.Close();
            }
            var fs = File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.WriteLine(logMessage);
                writer.Close();
            }
        }
    }
}
