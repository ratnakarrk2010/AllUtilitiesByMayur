﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using ValidateLicence;
using System.Net;

namespace EbioserverToHRMS
{
    class Program
    {
        static void Main(string[] args)
        {
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }
            StringBuilder logs = new StringBuilder();
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            string filenamePrefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];
            string localdestination = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";
            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            try
            {
                List<FileDataModel> FetchedData = new List<FileDataModel>();
                DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);

                List<FormulaHRAms.AmsSwipeDataUpload> FinalData = new List<FormulaHRAms.AmsSwipeDataUpload>();
                DataTable tblDeviceLogs = getData(logs, logDateToFetch);
                string filename = logDateToFetch.ToString("dd-MMM-yyyy") + ".txt";
                if (!Directory.Exists(localdestination))
                {
                    Directory.CreateDirectory(localdestination);
                }
                string path = localdestination + filename;
                var myFile = System.IO.File.Create(path);
                myFile.Close();
                string message = "";
                string EmployeeCode = "";
                foreach (DataRow row in tblDeviceLogs.Rows)
                {
                    
                    if (Convert.ToString(row.ItemArray[2]).Length == 1)
                        EmployeeCode = "0000000" + row.ItemArray[2];
                    else if (Convert.ToString(row.ItemArray[2]).Length == 2)
                        EmployeeCode = "000000" + row.ItemArray[2];
                    else if (Convert.ToString(row.ItemArray[2]).Length == 3)
                        EmployeeCode = "00000" + row.ItemArray[2];
                    else if (Convert.ToString(row.ItemArray[2]).Length == 4)
                        EmployeeCode = "0000" + row.ItemArray[2];
                    else if (Convert.ToString(row.ItemArray[2]).Length == 5)
                        EmployeeCode = "000" + row.ItemArray[2];
                    else if (Convert.ToString(row.ItemArray[2]).Length == 6)
                        EmployeeCode = "00" + row.ItemArray[2];
                    else if (Convert.ToString(row.ItemArray[2]).Length == 7)
                        EmployeeCode = "0" + row.ItemArray[2];
                    else
                        EmployeeCode = Convert.ToString(row.ItemArray[2]);



                    FileDataModel dataModel = new FileDataModel();
                    dataModel.DeviceId = row.ItemArray[0].ToString();
                    dataModel.LogDate = Convert.ToDateTime(row.ItemArray[1]);
                    dataModel.UserId = EmployeeCode;
                    FetchedData.Add(dataModel);
                }

                var employeeDataGroup = FetchedData.GroupBy(x => x.UserId).ToList();

                foreach (var empGroup in employeeDataGroup)
                {
                    var firstIn = empGroup.OrderBy(x => x.LogDate).FirstOrDefault();
                    var lastOut = empGroup.OrderByDescending(x => x.LogDate).FirstOrDefault();
                    

                    FormulaHRAms.AmsSwipeDataUpload firstInObj = new FormulaHRAms.AmsSwipeDataUpload();
                    FormulaHRAms.AmsSwipeDataUpload lastOutObj = new FormulaHRAms.AmsSwipeDataUpload();

                    firstInObj.CardNo = firstIn.UserId;
                    firstInObj.Card_Data = firstIn.Card_Data;
                    firstInObj.CheckIn_Out = firstIn.LogDate;
                    firstInObj.Type = "I";
                    FinalData.Add(firstInObj);

                    lastOutObj.CardNo = firstIn.UserId;
                    lastOutObj.Card_Data = lastOut.Card_Data;
                    lastOutObj.CheckIn_Out = lastOut.LogDate;
                    lastOutObj.Type = "O";
                    FinalData.Add(lastOutObj);



                    message += String.Format("{0}", "cc" + " " + firstIn.DeviceId + " " + firstIn.LogDate.ToString("ddMMyyyy") + " " + firstIn.LogDate.ToString("hhmm") + " " + empGroup.Key + " " + "00" + " " + "0000");
                    message += Environment.NewLine;
                    message += String.Format("{0}", "cc" + " " + firstIn.DeviceId+ " " + lastOut.LogDate.ToString("ddMMyyyy") + " " + lastOut.LogDate.ToString("HHmm") + " " + empGroup.Key + " " + "00" + " " + "0000");
                    message += Environment.NewLine;
                }

                var fs = System.IO.File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    writer.WriteLine(message);
                    writer.Close();
                }
                Console.WriteLine("File generated on local machine successfully..!");
                logs.AppendLine("Locally file '" + filename + "' generated successfully");
                SendData(logs, FinalData);
                logs.AppendLine("Data upload Successfully..!");
                Console.WriteLine("Data upload Successfully..!");

            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
            finally
            {
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
            }

        }
        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            try
            {

                string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
                string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string queryString = "select DeviceId,LogDate,UserId from " + tblDeviceLogs + " where LogDate >= '" + logDateToFetch.ToString("yyyy-MM-dd") + "' and LogDate < '" + logDateToFetch.AddDays(1).ToString("yyyy-MM-dd") + "' order by UserId";
                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.Fill(deviceLogs, "tblDeviceLogs");
                }
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
            return deviceLogs.Tables[0];
        }
        static void SendData(StringBuilder logs, List<FormulaHRAms.AmsSwipeDataUpload> FinalData)
        {
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.SystemDefault;
                string password = ConfigurationManager.AppSettings["PASSWORD"];
                FormulaHRAms.FormulaHRAms workLine = new FormulaHRAms.FormulaHRAms();
                var result = workLine.AmsSwipeDataBulkUpload(password, FinalData.ToArray());
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
        }
    }
    public class FileDataModel
    {
        public string UserId { get; set; }
        public DateTime LogDate { get; set; }
        public string DeviceId { get; set; }
        public string CardNo { get; set; } = "";
        public DateTime CheckIn_Out { get; set; }
        public string Type { get; set; } = "";
        public string Card_Data { get; set; } = "";
    }
}
