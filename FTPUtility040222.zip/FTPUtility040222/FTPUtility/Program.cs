﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using ValidateLicence;


namespace FTPUtility
{
    class Program
    {
        static void Main(string[] args)
        {

            //to check for licence
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }
            StringBuilder logs = new StringBuilder();
            StringBuilder errorLogs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            string timeEntryFormat = ConfigurationManager.AppSettings["TIME_ENTRY_DATE_FORMAT"];
            string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";

            try
            {

                DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);
               // DateTime logDateToFetch = DateTime.Today;
                DataTable tblDeviceLogs = getData(logs, logDateToFetch);


                foreach (DataRow row in tblDeviceLogs.Rows)
                {
                    IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                    fileContents.AppendLine(string.Join(",", fields));
                }

                string fileName_Prefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];
                string fileName_DateFormat = ConfigurationManager.AppSettings["FILENAME_DATE_FORMAT"];
                string fileName = fileName_Prefix + logDateToFetch.ToString(fileName_DateFormat) + ".csv";

                File.WriteAllText(localFolderPath + @"\" + fileName, fileContents.ToString());
                logs.AppendLine("Locally file '" + fileName + "' created successfully");
                Console.WriteLine("Locally file '" + fileName + "' created successfully");

                uploadFilesToFTP(fileName, fileContents.ToString(), logs);

            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
            finally
            {
                File.WriteAllText(logFolder + @"\" + "log_" + DateTime.Now.Ticks + ".txt", logs.ToString());
            }
        }

        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            try
            {
                string tblDevice = ConfigurationManager.AppSettings["TABLE_DEVICE"];
                string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
                string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                string logDateTime = ConfigurationManager.AppSettings["LOG_DATE_TIME"];
                string logDateTimeCondition = ConfigurationManager.AppSettings["LOG_DATE_TIME_CONDITION"];
                string direction_in = ConfigurationManager.AppSettings["DIRECTION_IN"];
                string direction_out = ConfigurationManager.AppSettings["DIRECTION_OUT"];
                string direction_altInOut = ConfigurationManager.AppSettings["DIRECTION_ALT_IN_OUT"];
                if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();// open the database connection  
                    //string queryString = "Select EmployeeCode,TimeEvent,convert(varchar,TimeEntry, 126)+ '.000+00:00' "
                    string queryString = "Select EmployeeCode,TimeEvent,CONVERT(CHAR(19),CONVERT(DATETIME,TimeEntry,101),121) "
                                        + "from("
                                        + "Select DL.UserID as EmployeeCode, Min(DL.LOgdate) as TimeEntry, 'IN' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId ";
                    //+ "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_altInOut + "' ";
                    //if (string.IsNullOrEmpty(logDateTime) == false)
                    //{
                    //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                    //}
                    queryString += "group by DL.UserID, Cast(DL.LogDate as date) "
                                    + "Union "
                                    + "Select DL.UserID as EmployeeCode, Min(DL.LOgdate) as TimeEntry, 'IN' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId ";
                    //+ "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_in + "' ";
                    //if (string.IsNullOrEmpty(logDateTime) == false)
                    //{
                    //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                    //}
                    queryString += "group by DL.UserID, Cast(DL.LogDate as date) "
                                    + "Union "
                                    + "Select DL.UserID as EmployeeCode, Max(DL.LOgdate) as TimeEntry, 'OUT' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId ";
                    //+ "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_altInOut + "' ";
                    //if (string.IsNullOrEmpty(logDateTime) == false)
                    //{
                    //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                    //}
                    queryString += "group by DL.UserID, Cast(DL.LogDate as date) "
                                    + "Union "
                                    + "Select DL.UserID as EmployeeCode, Max(DL.LOgdate) as TimeEntry, 'OUT' as TimeEvent from " + tblDeviceLogs + " DL join " + tblDevice + " D on DL.DeviceId = D.DeviceId ";
                    //+ "Where cast(DL.LogDate as date) = cast(CONVERT(VARCHAR(10), '" + logDateToFetch.ToString("yyyy-MM-dd") + "', 101) as datetime) and lower(DL.Direction) = '" + direction_out + "' ";
                    //if (string.IsNullOrEmpty(logDateTime) == false)
                    //{
                    //    queryString += "AND cast(DL.LogDate as time) " + logDateTimeCondition + " '" + logDateTime + "' ";
                    //}
                    queryString += "group by DL.UserID, Cast(DL.LogDate as date) "
                                    + ") as tblDeviceLogs";
                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);

                    adapter.Fill(deviceLogs, "tblDeviceLogs");
                }
            }
            catch (Exception ex)
            {
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
            }
            return deviceLogs.Tables[0];
        }

        static void uploadFilesToFTP(string fileName, string fileContents, StringBuilder logs)
        {
            string host = ConfigurationManager.AppSettings["HOST"];
            if (string.IsNullOrEmpty(host) == false)
            {
                string username = ConfigurationManager.AppSettings["USERNAME"];
                string password = ConfigurationManager.AppSettings["PASSWORD"];
                string ftpDestinationFolder = ConfigurationManager.AppSettings["FTP_DESTINATION_FOLDER"];

                string ftpFilePath = "ftp://" + host + ftpDestinationFolder + "/" + fileName;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpFilePath);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential(username, password);

                byte[] bytesFileContents = Encoding.Default.GetBytes(fileContents);
                request.ContentLength = fileContents.Length;

                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(bytesFileContents, 0, bytesFileContents.Length);
                }

                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                {
                    logs.AppendLine("Uploaded file '" + fileName + "' successfully");
                    Console.WriteLine("Uploaded file '" + fileName + "' successfully");
                }
            }
            else
            {
                logs.AppendLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
                Console.WriteLine("Upload file '" + fileName + "' is not successfull. Host name is blank");
            }
        }
    }
    //class BioMetricsData
    //{
    //    string employeeCode = string.Empty;
    //    DateTime timeEntry;
    //    string timeEvent = string.Empty;

    //    public string EmployeeCode { get => employeeCode; set => employeeCode = value; }
    //    public DateTime TimeEntry { get => timeEntry; set => timeEntry = value; }
    //    public string TimeEvent { get => timeEvent; set => timeEvent = value; }
    //}
    //    {
    //    List<BioMetricsData> bioMetricDataList = (from DL in dbEntity.DeviceLogs
    //                                              join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                              where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "altinout"
    //                                              group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                              select new BioMetricsData
    //                                              {
    //                                                  EmployeeCode = g.Key.UserId,
    //                                                  TimeEntry = g.Min(p => p.LogDate),
    //                                                  TimeEvent = "IN"
    //                                              }).Union
    //                                                            (from DL in dbEntity.DeviceLogs
    //                                                             join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                                             where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "in"
    //                                                             group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                                             select new BioMetricsData
    //                                                             {
    //                                                                 EmployeeCode = g.Key.UserId,
    //                                                                 TimeEntry = g.Min(p => p.LogDate),
    //                                                                 TimeEvent = "IN"
    //                                                             }).Union
    //                                                            (from DL in dbEntity.DeviceLogs
    //                                                             join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                                             where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "altinout"
    //                                                             group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                                             select new BioMetricsData
    //                                                             {
    //                                                                 EmployeeCode = g.Key.UserId,
    //                                                                 TimeEntry = g.Max(p => p.LogDate),
    //                                                                 TimeEvent = "OUT"
    //                                                             }).Union
    //                                                                (from DL in dbEntity.DeviceLogs
    //                                                                 join D in dbEntity.Devices on DL.DeviceId equals D.DeviceId
    //                                                                 where DbFunctions.TruncateTime(DL.LogDate) == logDateToFetch.Date && D.DeviceDirection.ToLower() == "out"
    //                                                                 group DL by new { DL.UserId, LogDate = DbFunctions.TruncateTime(DL.LogDate) } into g
    //                                                                 select new BioMetricsData
    //                                                                 {
    //                                                                     EmployeeCode = g.Key.UserId,
    //                                                                     TimeEntry = g.Max(p => p.LogDate),
    //                                                                     TimeEvent = "OUT"
    //                                                                 }).OrderBy(g => g.EmployeeCode).ToList<BioMetricsData>();
    //}
}
