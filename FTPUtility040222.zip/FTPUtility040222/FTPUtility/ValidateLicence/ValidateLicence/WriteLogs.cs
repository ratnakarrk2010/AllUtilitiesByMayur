﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidateLicence
{
    class WriteLogs
    {
        public static void LogException(Exception e)
        {
            var serverPath = AppDomain.CurrentDomain.BaseDirectory;
            string path = serverPath + "ErrorLog.txt";
            if (!File.Exists(path))
            {
                var myFile = File.Create(path);
                myFile.Close();
            }
            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            message += string.Format("Message: {0}", e.Message);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", e.StackTrace);
            message += Environment.NewLine;
            message += string.Format("Source: {0}", e.Source);
            message += Environment.NewLine;
            message += string.Format("TargetSite: {0}", e.TargetSite.ToString());
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            var fs = File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }

        public static void LogInfo(string userMessage)
        {
            var serverPath = AppDomain.CurrentDomain.BaseDirectory;
            string path = serverPath + "ErrorLog.txt";
            if (!File.Exists(path))
            {
                var myFile = File.Create(path);
                myFile.Close();
            }
            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            message += string.Format("Message: {0}", userMessage);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", message);
            message += Environment.NewLine;
            //message += string.Format("Source: {0}", e.Source);
            //message += Environment.NewLine;
            //message += string.Format("TargetSite: {0}", e.TargetSite.ToString());
            //message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            var fs = File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
            using (StreamWriter writer = new StreamWriter(fs))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }
    }
}
