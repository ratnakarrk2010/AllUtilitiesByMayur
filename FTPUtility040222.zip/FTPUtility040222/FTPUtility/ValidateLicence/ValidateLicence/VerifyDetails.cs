﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
//using WetosMVC.Controllers;

namespace ValidateLicence
{
    public class VerifyDetails
    {
        public static bool CompareDetails(string Path, string userName)
        {
            try
            {
				//NOTE: the date before encryption must be in yyyy-MM-dd format
                //string username = "";
                //var fromDate = new DateTime(2021, 04, 01);
                var toDate = DateTime.Today.AddDays(-1);
                //string systemHardwareId = "";

                if (File.Exists(Path))
                {
                    // Read text file line by line.  
                    string[] lines = File.ReadAllLines(Path);
                    foreach (string line in lines)
                    {
                        toDate = Convert.ToDateTime(Encryption.Decrypt(line)); //for only one line of encrypted toDate

                        //string[] param = line.Split(':');
                        //string param1 = param[1];
                        ////param1 = Encryption.Decrypt(param1);  //to get the decrypted value
                        //switch (param[0])
                        //{
                        //    case "Username":
                        //        username = param1; //param[1];
                        //        break;
                        //    case "FromDate":
                        //        fromDate = Convert.ToDateTime(param1);
                        //        break;
                        //    case "ToDate":
                        //        toDate = Convert.ToDateTime(param1);
                        //        break;
                        //    case "SystemHardwareId":
                        //        //Statement
                        //        break;
                        //    default:
                        //        //Statement
                        //        break;
                        //}
                    }
                }
                else
                {
                    WriteLogs.LogInfo("File not found at location: " + Path);
                }

                //if (DateTime.Now < toDate && DateTime.Now > fromDate)
                if (DateTime.Now < toDate)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                //WriteLogs.LogInfo("Inside catch of VerifyDeatils. " + ex.Message + " " + ex.StackTrace + " " + (ex.InnerException == null ? string.Empty : ex.InnerException.Message));
                WriteLogs.LogException(ex);
                return false;
            }
        }
    }
}
