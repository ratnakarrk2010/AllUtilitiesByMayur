﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using ValidateLicence;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace EviskaWebServiceUtility
{
    class Program
    {
        static void Main(string[] args)
        {
            //to check for licence
            string Licence = ConfigurationManager.AppSettings["LICENCE"];
            DateTime toDate = Convert.ToDateTime(Encryption.Decrypt(Licence));
            if (DateTime.Today > toDate)
            {
                SendEmailToUser(" Due to Licence Expired." );
                Console.WriteLine("Licence expired");
                Console.ReadKey();
                return;
            }

            StringBuilder logs = new StringBuilder();
            StringBuilder errorLogs = new StringBuilder();
            StringBuilder fileContents = new StringBuilder();
            int logDateInDays = Convert.ToInt32(ConfigurationManager.AppSettings["LOG_DATE_IN_DAYS"]);
            //string timeEntryFormat = ConfigurationManager.AppSettings["TIME_ENTRY_DATE_FORMAT"];
            //string localFolderPath = ConfigurationManager.AppSettings["LOCAL_DESTINATION_FOLDER"];
            //string filenamePrefix = ConfigurationManager.AppSettings["FILENAME_PREFIX"];
            string logFolder = AppDomain.CurrentDomain.BaseDirectory + @"\Log";

            try
            {
                List<FileDataModel> FetchedData = new List<FileDataModel>();
                //List<FileDataModel> FinalData = new List<FileDataModel>();
                List<hr.workline.hrscapes.AmsSwipeDataUpload> FinalData = new List<hr.workline.hrscapes.AmsSwipeDataUpload>();

                DateTime logDateToFetch = DateTime.Today.AddDays(-logDateInDays);

                //logDateToFetch = new DateTime(2021, 12, 13);//for testing 

                DataTable tblDeviceLogs = getData(logs, logDateToFetch);
                Console.WriteLine(tblDeviceLogs);
                //var serverPath = AppDomain.CurrentDomain.BaseDirectory;
                //string filename = filenamePrefix + logDateToFetch.ToString("ddMMyyyy") + ".txt";
                //string dir = serverPath + "Employee Punch Data\\";
                //if (!Directory.Exists(dir))
                //{
                //    Directory.CreateDirectory(dir);
                //}
                //string path = serverPath + "Employee Punch Data\\" + filename;
                //var myFile = System.IO.File.Create(path);
                //myFile.Close();
                //string message = "";
                //message += String.Format("{0},{1},{2},{3},{4}", "PS NO.", "DATE", "TIME", "TERMINAL ID", "P10/P20");

                foreach (DataRow row in tblDeviceLogs.Rows)
                {
                    FileDataModel dataModel = new FileDataModel();
                    dataModel.CardNo = row.ItemArray[0].ToString();
                    dataModel.CheckIn_Out = Convert.ToDateTime(row.ItemArray[1]);
                    dataModel.Type = "";//Convert.ToString(row.ItemArray[2]); //remove hardcoding "I"
                    dataModel.Card_Data = "";
                    FetchedData.Add(dataModel);
                }

                var employeeDataGroup = FetchedData.GroupBy(x => x.CardNo).ToList();

                foreach (var empGroup in employeeDataGroup)
                {
                    var firstIn = empGroup.OrderBy(x => x.CheckIn_Out).FirstOrDefault();
                    var lastOut = empGroup.OrderByDescending(x => x.CheckIn_Out).FirstOrDefault();

                    hr.workline.hrscapes.AmsSwipeDataUpload firstInObj = new hr.workline.hrscapes.AmsSwipeDataUpload();
                    hr.workline.hrscapes.AmsSwipeDataUpload lastOutObj = new hr.workline.hrscapes.AmsSwipeDataUpload();

                    firstInObj.CardNo = firstIn.CardNo;
                    firstInObj.Card_Data = firstIn.Card_Data;
                    firstInObj.CheckIn_Out = firstIn.CheckIn_Out;
                    firstInObj.Type = firstIn.Type;
                    FinalData.Add(firstInObj);

                    lastOutObj.CardNo = lastOut.CardNo;
                    lastOutObj.Card_Data = lastOut.Card_Data;
                    lastOutObj.CheckIn_Out = lastOut.CheckIn_Out;
                    lastOutObj.Type = lastOut.Type;
                    FinalData.Add(lastOutObj);

                    //message += Environment.NewLine;
                    //message += String.Format("{0},{1},{2},{3},{4}", empGroup.Key, firstIn.CheckIn_Out.ToString("yyyyMMdd"), firstIn.LogDate.ToString("HH:mm:ss"), firstIn.DeviceId, "P10");
                    //message += Environment.NewLine;
                    //message += String.Format("{0},{1},{2},{3},{4}", empGroup.Key, lastOut.CheckIn_Out.ToString("yyyyMMdd"), lastOut.LogDate.ToString("HH:mm:ss"), lastOut.DeviceId, "P20");
                }

                //var fs = System.IO.File.Open(path, FileMode.Append, FileAccess.Write, FileShare.Write);
                //using (StreamWriter writer = new StreamWriter(fs))
                //{
                //    writer.WriteLine(message);
                //    writer.Close();
                //}

                //uploadFilesToSFTP(path, fileContents.ToString(), logs);

                SendData(logs, FinalData);
            }
            catch (Exception ex)
            {
                SendEmailToUser("<br/>" + "System generated message- " + ex.Message);
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }

        static DataTable getData(StringBuilder logs, DateTime logDateToFetch)
        {
            DataSet deviceLogs = new DataSet();
            try
            {
                string tblDevice = ConfigurationManager.AppSettings["TABLE_DEVICE"];
                string tblDeviceLogs = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS"];
                string tblDeviceLogsSuffix = ConfigurationManager.AppSettings["TABLE_DEVICE_LOGS_SUFFIX_DATE_FORMAT"];
                string connectionString = ConfigurationManager.AppSettings["CONNECTION_STRING"];
                //string logDateTime = ConfigurationManager.AppSettings["LOG_DATE_TIME"];
                //string logDateTimeCondition = ConfigurationManager.AppSettings["LOG_DATE_TIME_CONDITION"];
                //string direction_in = ConfigurationManager.AppSettings["DIRECTION_IN"];
                //string direction_out = ConfigurationManager.AppSettings["DIRECTION_OUT"];
                //string direction_altInOut = ConfigurationManager.AppSettings["DIRECTION_ALT_IN_OUT"];
                if (string.IsNullOrEmpty(tblDeviceLogsSuffix) == false) tblDeviceLogs += logDateToFetch.ToString(tblDeviceLogsSuffix);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();// open the database connection  
                                     
                    string queryString = "select UserID, AuthDate from " + "Mx_ATDEventTrn" + " where AuthDate >= '" + logDateToFetch.ToString("yyyy-MM-dd") + "' and AuthDate < '" + logDateToFetch.AddDays(1).ToString("yyyy-MM-dd") + "'";
                                     
                    // string queryString = "select UserId, LogDate, DeviceId from DeviceLogs_2_2021 where LogDate >= '2019-02-01' and LogDate < '2019-02-02'";
                                      
                    // Define the date range based on `logDateToFetch`
                    //string startDate = logDateToFetch.ToString("yyyy-MM-dd");
                    //string endDate = logDateToFetch.AddDays(1).ToString("yyyy-MM-dd");

                    // Use the values from configuration and variables in the query string
                    //string queryString = $"SELECT UserId, LogDate, DeviceId FROM {tblDeviceLogs} WHERE LogDate >= '{startDate}' AND LogDate < '{endDate}'";

                    SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                    adapter.SelectCommand.CommandTimeout = 4000;
                    adapter.Fill(deviceLogs, "tblDeviceLogs");
                }

            }
            catch (Exception ex)
            {
                SendEmailToUser("<br/>" + "System generated message- " + ex.Message);
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            return deviceLogs.Tables[0];
        }

        static void SendData(StringBuilder logs, List<hr.workline.hrscapes.AmsSwipeDataUpload> FinalData)
        {
            //Email email = new Email();
            //email.UserName = "Neha";
            //email.Password = "Pratiksha@Sveltoz2021";
            //email.EmailID = "npisal@sveltoz.com";
            //email.Subject = "Data Transfer Failed.";
            //email.body = "Data Transfer Failed.";



            try
            {
                string password = "$er%#@pEc0D%";
                hr.workline.hrscapes.WorkLineAms workLine = new hr.workline.hrscapes.WorkLineAms();

                //var result = workLine.AmsSwipeDataUpload(password, DateTime.Now, "101", "I");
                var result = workLine.AmsSwipeDataBulkUpload(password, FinalData.ToArray());
                if(result == false)
                {
                    SendEmailToUser("<br/>" + "Application is currently not available.");
                }
                
            }
            catch (Exception ex)
            {
                //email.body += " Application is currently not available.";

                SendEmailToUser("<br/>"+"Workline website not accessible." +"<br/>"+" System generated message- " + ex.Message);
                logs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }

        static void SendEmailToUser(string exception)
        {
            try
            {

                //using (StreamReader reader = new StreamReader(email.Path))
                //{
                //    body = reader.ReadToEnd();
                //}
                //body = body.Replace("{UserName}", email.UserName);
                //body = body.Replace("{Password}", email.Password);
                //body = body.Replace("{Email}", email.EmailID);
                //body = body.Replace("{Url}", email.Url);
                //body = body.Replace("{ServerExt}", email.ServerExt);

                string Subject = "Data Transfer Failed.";
                string body = "Data Transfer Failed. " + exception;

                using (MailMessage mailMessage = new MailMessage())
                {
                    mailMessage.From = new MailAddress(Convert.ToString(ConfigurationManager.AppSettings["FromEmail"]));
                    //mailMessage.Subject = Subject + " " + email.UserName;
                    mailMessage.Subject = Subject ;
                    mailMessage.Body = body;
                    mailMessage.IsBodyHtml = true;
                    //mailMessage.To.Add(new MailAddress(email.EmailID));

                    string ToEmail = Convert.ToString(ConfigurationManager.AppSettings["ToEmail"]);
                    string cc = Convert.ToString(ConfigurationManager.AppSettings["CC"]);
                    string bcc = Convert.ToString(ConfigurationManager.AppSettings["BCC"]);
                    string[] ToMuliId = ToEmail.Split(',');
                    foreach (string ToEMailId in ToMuliId)
                    {
                        mailMessage.To.Add(new MailAddress(ToEMailId)); //adding multiple TO Email Id  
                    }

                    if(cc != "")
                    {
                        string[] CCId = cc.Split(',');
                        foreach (string CCEmail in CCId)
                        {
                            mailMessage.CC.Add(new MailAddress(CCEmail)); //Adding Multiple CC email Id  
                        }
                    }
                    

                    if(bcc!= "")
                    {
                        string[] bccid = bcc.Split(',');

                        foreach (string bccEmailId in bccid)
                        {
                            mailMessage.Bcc.Add(new MailAddress(bccEmailId)); //Adding Multiple BCC email Id  
                        }
                    }
                    



                    SmtpClient smtp = new SmtpClient();
                   
                    smtp.Host = Convert.ToString(ConfigurationManager.AppSettings["Host"]);
                    smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSsl"]);
                    System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                    NetworkCred.UserName = Convert.ToString(ConfigurationManager.AppSettings["Username"]);
                    NetworkCred.Password = Convert.ToString(ConfigurationManager.AppSettings["Password"]);
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
                    smtp.Send(mailMessage);
                   // context.UpdateIsEmailNotification(email.Id, true);
                }
            }
            catch (Exception ex)
            {
                //logs.AppendLine(ex.Message);
                //if(ex.InnerException !=null)
                //{
                //    errorLogs.AppendLine(ex.InnerException.ToString());
                //}
                //errorLogs.AppendLine(ex.Message);
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }

        public class FileDataModel
        {
            public string CardNo { get; set; } = "";
            public DateTime CheckIn_Out { get; set; }
            public string Type { get; set; } = "";
            public string Card_Data { get; set; } = "";
        }
        public class Email
        {
            public string UserName { get; set; }
            public string Subject { get; set; }
            public string Url { get; set; }
            public string Password { get; set; }
            public string EmailID { get; set; }
            public string Path { get; set; }
            public string ServerExt { get; set; }
            public int Id { get; set; }
            public bool IsEmailNotification { get; set; }
            public  string body { get; set; }
        }
    }
}
